from glfw.GLFW import *
from OpenGL.GL import *

from queue import Queue

if not glfwInit():#need thread safe, run by mainthread.
    raise Exception('glfw init error')


class Window:
    def __init__(self, size=(640, 480), windowname = 'a window'):
        w,h = size
        window = glfwCreateWindow(w, h, windowname, None, None)
        if not window:
            glfw.terminate()
        

        glfwSetKeyCallback(window, self.key_callback)
        glfwSetCursorPosCallback(window, self.cursor_pos_callback)
        
        #glfwSetWindowFocusCallback(window,xx)#whis this shares all?

        #glfwWindowHint(GLFW_DOUBLEBUFFER, True)
        
        glfwMakeContextCurrent(window)
        glfwSwapInterval(1)#1 to vsync.. 10 maybe 10x slower monitor hz.
        #NOTE: interval=1 60hz you can see mouse tracks little slowly.

        #while not glfwWindowShouldClose(window):
        #glfwTerminate()#This function destroys all remaining windows and cursors, 

        self.window = window
        self.size = size
        
        self.input_queue = Queue()
        self.mouse_x = 0
        self.mouse_y = 0

        self.on_update = lambda self:1
        self.draw_model = {}

    def key_callback(self, window, key, scancode, action, mods):
        if action == GLFW_PRESS:
            abskey = chr(key)
            value = int(action)
            data = {'abskey':abskey, 'value':value, 'from':'glfwwindow','time':411}
            self.input_queue.put(data)
        #if (key == GLFW_KEY_SPACE and action == GLFW_PRESS):
        #    print('space')
    
    def cursor_pos_callback(self, window, xpos,ypos):
        #https://www.glfw.org/docs/3.3/input_guide.html#events
        #see raw mouse motion
        W,H = self.size
        value = xpos/W*2-1
        self.mouse_x = value
        value = ypos/H*2-1
        self.mouse_y = value

    def poll_mouse(self):
        abskey = "MOUSE_X"
        value = self.mouse_x
        data = {'abskey':abskey, 'value':value, 'from':'glfwwindow','time':411}
        self.input_queue.put(data)
        abskey = "MOUSE_Y"
        value = self.mouse_y
        data = {'abskey':abskey, 'value':value, 'from':'glfwwindow','time':411}
        self.input_queue.put(data)
        

    def run(self):
        while not glfwWindowShouldClose(self.window):
            self.draw()
            #self._clear()
            #self._post()
    
    def _clear(self):
        glClearColor(0, 0.0, 0.5, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        x,y = 0.8,0.8
        sx,sy = 0.2,0.2
        glColor3f(0.5, 0.5, 0.5)
        glBegin(GL_TRIANGLES)
        verts = [
        [0+x,0+y,0],
        [sx+x,0+y,0],
        [0+x,sy+y,0],
        ]
        for vert in verts:
            glVertex3fv(vert)
        glEnd()

    def _post(self):

        glfwSwapBuffers(self.window)
        #glfwWaitEventsTimeout(5)
        glfwPollEvents()#this , is the input!
        
        self.poll_mouse()


    def get_inputs(self):
        inputs = []
        queue = self.input_queue
        while not queue.empty():
            i = queue.get()
            inputs.append(i)
        return inputs


    def draw(self):
        self._clear()

        self.on_update(self)#since outsider..

        def draw_tri(x,y,z):
            #x,y = 0.8,0.8
            sx,sy = 0.2,0.2
            glColor3f(0.9, 0.0, 0.5)
            glBegin(GL_TRIANGLES)
            verts = [
            [0+x,0+y,0],
            [sx+x,0+y,0],
            [0+x,sy+y,0],
            ]
            for vert in verts:
                glVertex3fv(vert)
            glEnd()

        # def draw_tri(x,y,z):
        #     1
        
        # Material
        # Vertex
        # Mesh
        # Geometry



        for id,data in self.draw_model.items():
            x,y,z = data['pos']
            #x,y = self.mouse_x,-self.mouse_y
            draw_tri(x,y,z)
        
        self._post()







def main():
    w = Window()

    class Xman:
        1
    pointer = Xman()
    pointer.x = 0
    pointer.direction = 1
    
    def movex(self):
        pointer.x += 0.01*pointer.direction
        #if abs( (x*2-1) )>1:
        if abs(pointer.x)>1:
            pointer.direction *= -1
        draws = {'id':{'pos':[pointer.x,0,0]}}

        #draws = {'id':{'pos':[w.mouse_x,-w.mouse_y,0]}}#slow tracking
        self.draw_model = draws        

    w.on_update = movex
    w.run()
    

if __name__ == '__main__':
    main()

