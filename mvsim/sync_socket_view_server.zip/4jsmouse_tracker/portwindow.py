from tortuga import Port

from postview import Window

import json


w = Window()
#port = AsyncPort()
port = Port()
port.run()

def onmsg(msg):
    1
port.on_message = onmsg

while True:
    data = w.get_inputs()

    strdata = json.dumps(data)
    port.put(strdata)

    strdata = port.get()
    data = json.loads(strdata)
    
    w.draw_model = data
    w.draw()
