from tortuga import Port

from postview import Window

import json


import time

from ws_clientsimple import WSClient


w = Window(vsync = False)

ws = WSClient()
def onmsg(msg):
    data = json.loads(msg)
    w.draw_model = data

ws.on_message = onmsg


def updater(self):
    inputs = w.get_inputs()
    for i in inputs:
        strdata = json.dumps(i)
        ws.send(strdata)
    time.sleep(0.001)

w.on_draw = updater

w.run()