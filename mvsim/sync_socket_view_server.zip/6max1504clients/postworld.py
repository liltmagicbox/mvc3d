import time
import random
import uuid

from queue import Queue

import math



class Simulator:
	def __init__(self, view_control):
		self.view_control = view_control
		self.time = 0		
	def run(self, world):
		self.time = time.perf_counter()
		while True:
			tnow = time.perf_counter()
			dt = tnow - self.time
			self.time = tnow
			
			ninputs = []
			inputs = self.view_control.get_inputs()			
			for i in inputs:
				ff = i['from']
				if not 'Win64' in ff:
					continue
				#Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36
				#Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36
				#Mozilla/5.0 (Linux; Android 9; H8314 Build/52.0.A.11.32; wv) AppleWebKit/537.36 (KHTML, like Gecko) Version/4.0 Chrome/105.0.5195.79 Mobile Safari/537.36 Line/12.15.1/IAB

				key = i['abskey']
				value = i['value']
				ni = Input('5549',key,value)
				ninputs.append(ni)

			inputs = ninputs
			world.input(inputs)
			world.update(dt)
			draws = world.draw()

			self.view_control.draw(draws)
			time.sleep(0.001)#this causes jitter
			# for i in range(150000):
			# 	time.time()

class World:
	def __init__(self):
		self.actorDict = {}
	def add(self,actor):
		self.actorDict[actor.id] = actor
	def remove(self,actor):
		if actor.id in self.actorDict:
			self.actorDict.pop(actor.id)
	def get(self,id):
		return self.actorDict.get(id)

	def input(self,inputs):
		for i in inputs:
			targetid = i.target
			if targetid in self.actorDict:
				actor = self.actorDict[targetid]
				actor.input(i)
		
	def update(self,dt):
		for id,actor in self.actorDict.items():
			if id=='5549':
				continue
			actor.update(dt)	
	def draw(self):
		draws = {}
		for id,actor in self.actorDict.items():
			draw_data = {'pos':actor.pos}
			draws[actor.id] = draw_data
		return draws


keymap_general={
	'F':'jump',
	'W':'move_forward*1.0',
	'MOUSE_X': 'setx*1',
	'MOUSE_Y': 'sety*-1',
}


def keymap_parse(actor,keymap,i):
	if i.key in actor.keymap:
		funcname = actor.keymap[i.key]
		
		if '*' in funcname:
			funcname, mul = funcname.split('*')
			mul = float(mul)
		else:
			mul = None
		if hasattr(actor, funcname):
			func = getattr(actor,funcname)
			if mul == None:
				if i.value>0:
					func()
			else:
				func(i.value*mul)



class Actor:
	count = 0
	def __init__(self):
		self.id = str(uuid.uuid4()).replace('-','_')
		self.name = f"{self.__class__.__name__}_{Actor.count}"
		Actor.count += 1
		#===
		#self.keymap = {'f':lambda actor,key,value:print('-input:',actor,key,value)}
		self.keymap = keymap_general
		self.pos = [0,0,0]
		#===
		self.t = 0
	def __repr__(self):
		return f"{self.name}"

	def update(self,dt):
		self.t+=dt
		x = math.cos(self.t)*0.8
		y = math.sin(self.t)*0.8
		self.pos[0:2] = x,y

	def input(self,i):
		keymap_parse(self,self.keymap, i)
	
	def jump(self):
		print('jump!')
	def setx(self, x):
		self.pos[0] = x
	def sety(self, y):
		self.pos[1] = y


class Input:
	#__slots__ = ['target','key','value']
	def __init__(self, target, key,value,):
		self.target = target
		self.key = key
		self.value = value
	def __repr__(self):
		return f"{self.target}:{self.key},{self.value}"

def actorkeytest():
	a = Actor()
	i = Input(None,'f', 1.0)
	a.input(i)

actorkeytest()

def worldupdatetest():
	w = World()
	a = Actor()
	w.add(a)

	i = Input(a.id,'f',1.0)
	w.input([i])
	w.update(0.1)
	d = w.draw()
	print(d)

worldupdatetest()


class Inputman:
	def __init__(self):
		self.queue = Queue()

	def get(self):
		queue = self.queue
		inputs = []
		while not queue.empty():
			i = queue.get()
			inputs.append(i)
		return inputs

#from postview import Renderer
from postview import Window



import json
from tortuga import Port

class DummyWindow:
    def __init__(self):
        self.port = Port()
        self.port.connect()
    def get_inputs(self):
        strdata = self.port.get()
        if strdata:
        	return json.loads(strdata)
        else:
        	return []
    def draw(self,draws):
        strdata = json.dumps(draws)
        self.port.put(strdata)


import json

def simtest():
	window = DummyWindow()
	s = Simulator(window)

	w = World()
	a = Actor()
	a.id = '5549'
	w.add(a)

	#{uuidxxxxxxxxxxxxxxxxxxxx:{'pos':[0.000000000,0.000000000,0.0000000000]}}
	#~70Bytes.
	#16 4x4 reqs ..70Bytes. same as.  or 100Bytes.
	#120bones, 100bones, 100B, 0.1KB, 100Bones will 10KB/skmodel
	#6 skmodel, 60KB/tick.

	#150*70B *4clients =>  600*70B = 6000*7B = 42KB/tick.

	#60KB/tick  , 100fps, 6MB/s.fine.

	#detected max 45Mbit/s, quite 4MB/s.
	
	for i in range(150):# 150 4clinents fine while 500 4clinent NOT ACCEPTABLE!
		#youcan even asyncio shild pings error.
		a = Actor()
		a.t = random.random()*5
		w.add(a)
	s.run(w)

simtest()

