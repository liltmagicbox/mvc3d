import threading
import socket
import json
from queue import Queue
import time

HOST = socket.gethostbyname(socket.gethostname())
PORT = 30020


#======= this reconnects even server's state. if disconnected, recvs data=''.if fail connection,CRE.
#whatever, queue will get what's came from. recv halts, cpu power safe.

def recv_forever(put_function, host, port, verbose):

    def connect():
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        
        tryagain = True
        while tryagain:
            try:
                client.connect( (host,port) )
                tryagain = False                
            except ConnectionRefusedError:
                print('reconnecting..') if verbose else 1
                continue
        print('connected!') if verbose else 1
        return client

    sock = connect()

    while True:
        try:
            data = sock.recv(2**13)#12=4096
        except ConnectionResetError:
            sock = connect()
            continue
        if not data:#also server disconnected. b'' will no response. lets assume disconnected.
            sock = connect()
            continue
        strdata = data.decode()
        #print(strdata,'what')#["hello"]["hello"]
        try:
            parsed_data = json.loads(strdata)
        except json.decoder.JSONDecodeError:
            print('seems the loop is too fast, and server resetted.')
            raise TypeError
        
        put_function(parsed_data)        

#============
def thread_run(data_dealer, host,port, verbose = False):
    th = threading.Thread( target = recv_forever, args=[data_dealer, host,port, verbose])
    th.start()



#===========================
def main():
    queue = Queue()
    def getter(data):
        queue.put(data)

    thread_run(getter, HOST,PORT, verbose =True)

    while True:
        while not queue.empty():
            g = queue.get()
            print(g)
        else:#else of while!
            print('/',end='')
        time.sleep(0.1)

if __name__ == '__main__':
    main()




#portdog = Portdog(host,port, queue)#whatever connected, gets and puts to queue.

#finally!
#portqueue = PortQueue(host,port)
#portqueue.get_all()


class PortQueue:
    def __init__(self, host=HOST, port=PORT):
        queue = Queue()
        self.queue = queue
        def putter(data):
            queue.put(data)
        
        thread_run(putter, host,port)
    
    def get_all(self):
        queue = self.queue
        while not queue.empty():
            yield queue.get()

def pqtest():
    a = PortQueue()
    while True:
        for i in a.get_all():
            print(i)
        time.sleep(1)

 # 'accept'
 #  'bind'
 #  'close'
 #  'connect'
 #  'connect_ex'
 #  'detach'
 #  'dup'
 #  'family'
 #  'fileno'
 #  'get_inheritable'
 #  'getblocking'
 #  'getpeername'
 #  'getsockname'
 #  'getsockopt'
 #  'gettimeout'
 #  'ioctl'
 #  'listen'
 #  'makefile'
 #  'proto'
 #  'recv'
 #  'recv_into'
 #  'recvfrom'
 #  'recvfrom_into'
 #  'send'
 #  'sendall'
 #  'sendfile'
 #  'sendto'
 #  'set_inheritable'
 #  'setblocking'
 #  'setsockopt'
 #  'settimeout'
 #  'share'
 #  'shutdown'
 #  'timeout'
 #  'type'
