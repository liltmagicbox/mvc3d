#!/usr/bin/env python

import json
import asyncio
import websockets
import socket

from queue import Queue
from tortuga import Port


HOSTIP = socket.gethostbyname(socket.gethostname())

class Broadcaster:
    def __init__(self, host=HOSTIP, port=30020):
        #localhost, "192.168.0.47"(localipaddress) ..even texturl.
        self.host = host
        self.port = port
        #self.uri = f"ws://{host}:{port}/"

        self.in_queue = Queue()
        
        self.sport = Port()
        self.sport.run()

    def run(self):
        """forever"""
        CONNECTIONS = set()
        print('runn')
        async def register(websocket):
            #if message == 'watch': ===not actually. register is the 1st conection.
            CONNECTIONS.add(websocket)
            print('connected',len(CONNECTIONS),websocket)

            try:
                #await websocket.wait_closed()
                async for message in websocket:#this is for,, with forever!
                    self.in_queue.put(message)                    
                    
                    #send back, but function too big. server simple best.
                    # if data_back !=None:
                    #     await websocket.send(data_back)
                    
                    #RuntimeWarning: Enable tracemalloc to get the object allocation traceback
                    #await added, works fine.

            except websockets.exceptions.ConnectionClosedError:
                #cannot read message from async for message in websocket:
                pass
                #print(type(e))<class 'websockets.exceptions.ConnectionClosedError'>
            #raise self.connection_closed_exc()
            #websockets.exceptions.ConnectionClosedError: no close frame received or sent

            finally:
                CONNECTIONS.remove(websocket)#it rellay finally disconnected.        
                print('DISCONNECTED',len(CONNECTIONS), websocket)



        async def show_time():
            while True:
                #print(len(CONNECTIONS),CONNECTIONS)#connection preserved!
                
                #self.sport.put('this is from sport')
                #d = self.sport.get()
                #print(d)
                
                items = []
                while not self.in_queue.empty():
                    item = self.in_queue.get()
                    item = json.loads(item)
                    items.append(item)
                items_str = json.dumps(items)
                self.sport.put(items_str)
                
                data = self.sport.get()
                if data:
                    websockets.broadcast(CONNECTIONS, data)
                await asyncio.sleep(0.001)#this is the blocker! #e-05 fast. not 14ms..?
        
        async def main():
            async with websockets.serve(register, self.host, self.port):
                await show_time()
        asyncio.run( main() )


def main():
    #all inputs, stacked in queue. and sent via socket when broadcasted..?
    b = Broadcaster()
    b.run()

if __name__ == '__main__':
    main()
