from tortuga import Port

from postview import Window

import json




from ws_clientsimple import WSClient


w = Window()

ws = WSClient()
def onmsg(msg):
    data = json.loads(msg)
    w.draw_model = data

ws.on_message = onmsg

while True:
    inputs = w.get_inputs()
    for i in inputs:
        strdata = json.dumps(i)
        ws.send(strdata)
    w.draw()
