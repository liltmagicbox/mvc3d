from queuerecv import Sender


import time

s = Sender(host='192.168.0.47', verbose=True)

data = round(time.time()%10,3)
while True:
	s.send( {'id':data})
	time.sleep(0.1)
