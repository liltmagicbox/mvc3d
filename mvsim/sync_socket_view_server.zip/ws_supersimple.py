import asyncio
import websockets

import json
import time
import math

async def accept(websocket, path):
    counter=0
    while True:
        #data = await websocket.recv();# 클라이언트로부터 메시지를 대기한다.
        #print("receive : " + data);

        t = time.time()
        dt = 0.000000006812
        x = math.cos(t+dt)*3
        y = math.sin(t+dt)*3+1
        #data = {'pos':[x,y,0],'time':t}
        #data = json.dumps(data)
        data = f"{x},{y}"

        #data = str(t)+'____'+str(counter)
        #counter+=1
        #print(data)
        
        await websocket.send(data)
        await asyncio.sleep(0.002)

        #data = await websocket.recv()
        #print(data,'recv')
        
        

start_server = websockets.serve(accept, "192.168.0.47", 30020);

asyncio.get_event_loop().run_until_complete(start_server)
asyncio.get_event_loop().run_forever();
