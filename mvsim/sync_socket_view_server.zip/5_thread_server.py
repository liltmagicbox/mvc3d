from queuerecv import QueueServer

q = QueueServer(verbose=True)

import time
while True:
	for i in q.get_all():
		print(i)
	print('zzz')
	time.sleep(3)
