#https://pypi.org/project/three-py/
import three
from wgpu.gui.auto import WgpuCanvas, run

canvas = WgpuCanvas(size=(640, 480), title="wgpu_renderer")

render = three.WgpuRenderer(canvas, parameters={'antialias': True})
render.init()

camera = three.PerspectiveCamera(70, 640 / 480, 0.01, 100)
camera.position.z = 1

scene = three.Scene()

geometry = three.BoxGeometry(0.2, 0.2, 0.2)
material = three.MeshNormalMaterial()

mesh = three.Mesh(geometry, material)

mesh2 = three.Mesh(geometry, material)
mesh2.position.x+=0.5
mesh.add(mesh2)

scene.add(mesh)



import json
from tortuga import Port
port = Port()
port.run()

def loop():
    data=[]
    strdata = json.dumps(data)
    port.put(strdata)

    strdata = port.get()
    data = json.loads(strdata)
    
    for id,drawdata in data.items():
        x,y,z = drawdata['pos']
        mesh.position.x = x
        mesh.position.y = y
    #mesh.rotation.x += 0.01
    #mesh.rotation.y += 0.02
    render.render(scene, camera)

render.setAnimationLoop(loop)

run()