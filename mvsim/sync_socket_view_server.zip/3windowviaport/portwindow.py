from tortuga import Port

from postview import Window

import json


w = Window()
port = Port()
port.run()

while True:
    data = w.get_inputs()
    strdata = json.dumps(data)
    port.put(strdata)
    strdata = port.get()
    data = json.loads(strdata)
    w.draw(data)
