import socket

def recvall(sock,n):
    maxbuffer = 2**13#20max. 12 4096
    
    data = bytearray()
    while len(data) < n:
        remain_bytes = n-len(data)
        recvlen = maxbuffer if remain_bytes>maxbuffer else remain_bytes
        packet = sock.recv(recvlen)
        if not packet:
            return None
        data.extend(packet)
    return data

def get(sock):
    """data is str"""
    dlen = int(sock.recv(16).decode())
    data = recvall(sock,dlen)    
    return data.decode()

def put(sock,data):
    """data is str"""
    data = data.encode()
    dlen = str(len(data)).zfill(16).encode()
    sock.sendall(dlen)
    sock.sendall(data)
    


class Port:    
    def __init__(self, host='localhost', port=30030):
        self.host = host
        self.port = port
        self.server_socket = None
        self.sock = None
    
    def run(self):
        """is server. put first?"""
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind( (self.host,self.port) )
        server_socket.listen()
        conn, addr = server_socket.accept()
        
        self.sock = conn
        self.server_socket = server_socket

    def reconnect(self):
        self.sock.close()
        if self.server_socket:            
            conn, addr = self.server_socket.accept()
            self.sock = conn
        else:
            self.connect()

    def connect(self):
        """is client. get first?"""
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect( (self.host,self.port) )
        ConnectionRefusedError
        self.sock = client

    def put(self,data):
        try:
            put(self.sock,data)
        except ConnectionResetError:
            self.reconnect()

    def get(self):
        try:
            return get(self.sock)
        except ConnectionResetError:
            self.reconnect()


def server():
    a = Port()
    a.run()
    while True:
        a.put('this is from server')
        d = a.get()
        print(d)

def client():
    import time

    a = Port()
    a.connect()

    while True:
        d = a.get()
        print(d)
        time.sleep(0.51)
        a.put('["socket", "clientdata"]')



def client2():
    import time
    import json
    import math

    a = Port()
    a.connect()

    x=0
    direction = 1
    while True:
        d = a.get()
        if d !='[]':
            1#print(d)
        #time.sleep(0.0121)
        #time.sleep(0.0001) #if 15ms delay, js will be 30fps
        t = time.time()
        x = math.cos(t)*3
        y = math.sin(t)*3+1
        data = {'pos':[x,y,0],'time':t}        
        a.put( json.dumps( data) )
        continue
        

        if x>1:
            direction = -1
        if x<0:
            direction = 1
        #x += direction * 0.01

        data = {}
        
        if 'ArrowRight' in d:
            x+=0.1
            data = {'pos':[x,0,0]}
        if 'ArrowLeft' in d:
            x-=0.1
            data = {'pos':[x,0,0]}
        
        if 'f' in d:
            data = {'color':[0,255,0]}
        if 'd' in d:
            data = {'color':[0,128,128]}

        if 'mouseX' in d:
            idx = d.rfind('mouseX')
            xpos = d[idx+9 : idx+12].replace(',','')            
            #print(idx, xpos)
            
            try:
                x = (int(xpos)/600)*3 -1
            except:
                x = 0
            data = {'pos':[x,0,0]}
        
        a.put( json.dumps( data) )
        


