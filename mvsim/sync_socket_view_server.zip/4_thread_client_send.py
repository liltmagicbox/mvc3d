import threading
import socket
import json
from queue import Queue
import time

HOST = socket.gethostbyname(socket.gethostname())
PORT = 30020

host,port = HOST,PORT


verbose = True
def connect():
	client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	while True:
		try:
			client.connect( (host,port) )
			break
		except ConnectionRefusedError:
			print('reconnecting..') if verbose else 1
			continue
	print('connected!') if verbose else 1
	return client

sock = connect()
print(sock)

while True:
	try:
		sock.sendall('["hello"]'.encode())
		print('sent')
	except ConnectionResetError:
		print('reconnect')
		sock = connect()		
		continue	
	time.sleep(1)

exit()

def listen():
	client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	return conn

conn = listen()

while True:
	try:
		conn.sendall( ''.encode())#b'' not sends.
		conn.sendall( '["hello"]'.encode())
	except ConnectionResetError:
		conn = listen()
		continue

	time.sleep(0.1)	