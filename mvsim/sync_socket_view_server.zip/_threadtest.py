import threading
import time


def thread_appends_while_iter():
	lili = []

	def append():
		for i in range(100):
			lili.append(i)
			time.sleep(0.3)
	threading.Thread(target = append).start()

	time.sleep(1)
	for i in lili:
		print(i, len(lili))
		#lili.pop()
		time.sleep(1)
# 0 4
# 1 7
# 2 10
# 3 14
# 4 17
# 5 20
# 6 24
# 7 27
# 8 30
#not ends forever..
#thread_appends_while_iter()

def list_changes_while_thread_iterates():
	lili = [i for i in range(20)]

	def slowiter():
		for i in lili:
			print(i)
			time.sleep(0.3)
	threading.Thread(target = slowiter).start()

	time.sleep(1)
	for i in range(10):
		lili.pop()
	#lili.append(99)


def ver1():
	non = []

	def nah(li):
		while True:
		    print(len(li))
		    time.sleep(1)
		    if len(li)>50:
		    	break
	threading.Thread(target = nah, args = [non]).start()

	while True:
	    non.append(1)
	    time.sleep(0.1)
	    if len(non)>50:
		    	break
	print(len(non))

#ver1()
#this not re-assignes var. so list kept.


def ver2():
	li = []

	def nah():
		while True:
		    print(len(li))
		    time.sleep(1)
		    if len(li)>50:
		    	break
	threading.Thread(target = nah).start()

	while True:
	    li.append(1)
	    time.sleep(0.1)
	    if len(li)>50:
		    	break
	print(len(li))

#ver2()
#same.fine. since it's thread, shared memory.