import threading
import time

class World:
    def __init__(self):
        self.actors = []
    def add(self,actor):
        self.actors.append(actor)
    def draw(self):
        return self.actors
    def update(self,dt):
        self.actors.append(2)


class Simulator:
    def __init__(self):
        self.flag = None
    def run(self,world):
        if self.flag:
            self.flag.set()

        flag = threading.Event()
        def simrun(world):
            t = time.perf_counter()
            t_before = t
            while not flag.is_set():
                t = time.perf_counter()
                dt = t - t_before
                t_before = t

                world.update(dt)
                #print( world.draw() )
                print( len(world.actors))
                time.sleep(1)
                #time.sleep(0.0000001)#~14.5ms. ~70fps.        
        
        th = threading.Thread( target = simrun, args=[world])
        th.start()
        self.flag = flag

world = World()
world.add(1)

s = Simulator()
s.run(world)

time.sleep(3)
world.add(99)
print(world)
world = None#not affects the one in the thread.
print(world)

world = World()
print(world)
s.run(world)

time.sleep(3)

world = World()
print(world)
for i in range(100):
    world.add(99)
s.run(world)