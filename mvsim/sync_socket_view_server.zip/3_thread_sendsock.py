import threading
import socket
import json
from queue import Queue
import time

HOST = socket.gethostbyname(socket.gethostname())
PORT = 30020

host,port = HOST,PORT

def listen():
	server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
	server_socket.bind( (host,port) )
	server_socket.listen()
	conn, addr = server_socket.accept()	
	return conn

conn = listen()

while True:
	try:
		conn.sendall( ''.encode())#b'' not sends.
		conn.sendall( '["hello"]'.encode())
	except ConnectionResetError:
		conn = listen()
		continue

	time.sleep(0.1)	