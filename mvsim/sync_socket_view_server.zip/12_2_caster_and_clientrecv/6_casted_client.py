from queuerecv import QueueRecvClient
import time


a = QueueRecvClient(verbose = True)

while True:
    for i in a.get_all():
    	print(i)
    time.sleep(2)
