from glfw.GLFW import *
from OpenGL.GL import *

from queue import Queue

if not glfwInit():#need thread safe, run by mainthread.
    raise Exception('glfw init error')


#SEE SWASP INTERVAL 1 IS ANYWAY SLOW

class Window:
    def __init__(self, windowname = 'a window'):
        window = glfwCreateWindow(640, 480, windowname, None, None)
        if not window:
            glfw.terminate()

        glfwSetKeyCallback(window, self.key_callback)
        glfwSetCursorPosCallback(window, self.cursor_pos_callback)
        
        #glfwSetWindowFocusCallback(window,xx)#whis this shares all?

        #glfwWindowHint(GLFW_DOUBLEBUFFER, True)
        
        glfwMakeContextCurrent(window)
        glfwSwapInterval(1)#1 to vsync.. 10 maybe 10x slower monitor hz.
        #NOTE: interval=1 60hz you can see mouse tracks little slowly.

        #while not glfwWindowShouldClose(window):
        #glfwTerminate()#This function destroys all remaining windows and cursors, 

        self.window = window
        self.queue = Queue()
        self.mouse_x = 0
        self.mouse_y = 0

    def key_callback(self, window, key, scancode, action, mods):
        if action == GLFW_PRESS:
            abskey = chr(key)
            value = int(action)
            data = {'abskey':abskey, 'value':value, 'from':'glfwwindow','time':411}
            self.queue.put(data)
        #if (key == GLFW_KEY_SPACE and action == GLFW_PRESS):
        #    print('space')
    
    def cursor_pos_callback(self, window, xpos,ypos):
        abskey = "MOUSE_X"
        value = xpos/640*2-1
        #data = {'abskey':abskey, 'value':value, 'from':'glfwwindow','time':411}
        #self.queue.put(data)
        self.mouse_x = value

        abskey = "MOUSE_Y"
        value = ypos/480*2-1
        #data = {'abskey':abskey, 'value':value, 'from':'glfwwindow','time':411}
        #self.queue.put(data)
        self.mouse_y = value
    def mouse_put(self):
        abskey = "MOUSE_X"
        value = self.mouse_x
        data = {'abskey':abskey, 'value':value, 'from':'glfwwindow','time':411}
        self.queue.put(data)
        abskey = "MOUSE_Y"
        value = self.mouse_y
        data = {'abskey':abskey, 'value':value, 'from':'glfwwindow','time':411}
        self.queue.put(data)
        

    def run(self):
        while not glfwWindowShouldClose(self.window):
            self.draw()
            #self._clear()
            #self._post()
    
    def _clear(self):
        glClearColor(0, 0.0, 0.5, 1.0)
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        x,y = 0.8,0.8
        sx,sy = 0.2,0.2
        glColor3f(0.5, 0.5, 0.5)
        glBegin(GL_TRIANGLES)
        verts = [
        [0+x,0+y,0],
        [sx+x,0+y,0],
        [0+x,sy+y,0],
        ]
        for vert in verts:
            glVertex3fv(vert)
        glEnd()

    def _post(self):
        self.mouse_put()

        glfwSwapBuffers(self.window)
        #glfwWaitEventsTimeout(5)
        glfwPollEvents()#this , is the input!


    def get_inputs(self):
        inputs = []
        queue = self.queue
        while not queue.empty():
            i = queue.get()
            inputs.append(i)
        return inputs

    def draw(self,draws={}):
        self._clear()

        glfwPollEvents()
        self.mouse_put()

        #xpos,ypos = glfwGetCursorPos(self.window)
        #x = xpos/640*2-1
        #y = -1*(ypos/480*2-1)
        
        x,y = self.mouse_x,-self.mouse_y
        
        sx,sy = 0.2,0.2
        glColor3f(0.9, 0.0, 0.5)
        glBegin(GL_TRIANGLES)
        verts = [
        [0+x,0+y,0],
        [sx+x,0+y,0],
        [0+x,sy+y,0],
        ]
        for vert in verts:
            glVertex3fv(vert)
        glEnd()
        #self._post() 
        glfwSwapBuffers(self.window)
        return

        def draw_tri(x,y,z):
            #x,y = 0.8,0.8
            sx,sy = 0.2,0.2
            glColor3f(0.9, 0.0, 0.5)
            glBegin(GL_TRIANGLES)
            verts = [
            [0+x,0+y,0],
            [sx+x,0+y,0],
            [0+x,sy+y,0],
            ]
            for vert in verts:
                glVertex3fv(vert)
            glEnd()

        for id,data in draws.items():
            x,y,z = data['pos']
            x,y = self.mouse_x,-self.mouse_y
            draw_tri(x,y,z)
        
        self._post()    

def main():
    w = Window()

    direction = 1
    x = 0
    while not glfwWindowShouldClose(w.window):
        x += 0.01*direction
        #if abs( (x*2-1) )>1:
        if abs(x)>1:
            direction *= -1
        draws = {'id':{'pos':[x,0,0]}}

        #draws = {'id':{'pos':[w.mouse_x,-w.mouse_y,0]}}#slow tracking
        w.draw(draws)

    #w.run()


if __name__ == '__main__':
    main()