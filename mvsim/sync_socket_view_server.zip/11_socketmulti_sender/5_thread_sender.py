from queuerecv import Sender


import time

s = Sender(verbose=True)

data = round(time.time()%10,3)
while True:
	s.send( {'hello':data})
	time.sleep(1)