import threading
import socket
import json
from queue import Queue
import time

HOST = socket.gethostbyname(socket.gethostname())
PORT = 30020


def get_server(host,port,verbose):
    max_port = 5

    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    while True:
        try:
            server_socket.bind( (host,port) )#OSError: [WinError 10048]
            break
        except OSError as err:
            print(err) if verbose else 1
            if '10048' in str(err):
                raise Exception('PORT occupied already')
            break
    server_socket.listen(max_port)
    return server_socket

def get_conn(server_socket, verbose):
    print('accepting..') if verbose else 1
    conn, addr = server_socket.accept()
    print('client connected', addr) if verbose else 1
    return conn


#======= this reconnects even server's state. if disconnected, recvs data=''.if fail connection,CRE.
#whatever, queue will get what's came from. recv halts, cpu power safe.

def server_recv_forever(host,port, put_function=None, verbose=False):
    if put_function == None:
        put_function = lambda data:print('put',data)

    server_socket = get_server(host,port,verbose)

    while True:
        sock = get_conn(server_socket, verbose)
        #seems this is garbage collected. 1s lieftime,,
        def sock_to_queue(sock):
            while True:
                try:
                    data = sock.recv(2**13)
                except ConnectionResetError:
                    #sock = get_conn(server_socket, verbose)
                    break
                #ConnectionResetError: [WinError 10054] 현재 연결은 원격 호스트에 의해 강제로 끊겼습니다
                put_function(data)
        th = threading.Thread( target = sock_to_queue, args=[sock] )
        th.start()
        #print('newthread!',th)

    return
    print('youcannotseethis')

    sock = get_conn(server_socket, verbose)

    while True:
        try:
            data = sock.recv(2**13)
        except ConnectionResetError:
            print('client disconnected') if verbose else 1
            #sock = #we just finish here.. break ..no!            
            sock = get_conn(server_socket, verbose)
            continue

        if not data:#connection end
            print('client connection end') if verbose else 1
            sock = get_conn(server_socket, verbose)
            continue
        
        strdata = data.decode()        
        try:
            parsed_data = json.loads(strdata)
            put_function(parsed_data)
        except json.decoder.JSONDecodeError:
            print('json decode failed:',data) if verbose else 1
            continue

#==================
def _test_server_without_class():
    th = threading.Thread( target = server_recv_forever, args=[HOST,PORT])
    th.start()
    
    print('main thread sleep')
    time.sleep(40)

#_test_server_without_class()





class QueueRecv:
    """open server socket, run thread, if new conn, put to queue."""
    def __init__(self, host=HOST, port=PORT, verbose=False):
        queue = Queue()
        def put_function(data):
            queue.put(data)
        th = threading.Thread( target = server_recv_forever, args=[HOST,PORT, put_function, verbose])
        th.start()
        self.queue = queue

    def get_all(self):
        queue = self.queue
        while not queue.empty():
            yield queue.get()

#==================
def _qstest():
    q = QueueRecv(verbose = True)

    while True:
        for i in q.get_all():
            print(i)
        time.sleep(2)

def main():
    #server_recv_forever(HOST,PORT, verbose = True)
    _qstest()
if __name__ == '__main__':
    main()





















#======================== client version


def get_client(host, port, verbose):
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    while True:
        try:
            client.connect( (host,port) )
            break
        except ConnectionRefusedError:
            print('reconnecting..') if verbose else 1
            continue
    print('connected!',client.getsockname() ) if verbose else 1
    return client

#def get_client_threaded(host, port, verbose):

#===========client sender
class Sender:
    def __init__(self, host=HOST,port=PORT,verbose=False, reconnect=True):
        self._data = (host,port,verbose)
        self.sock = get_client(host, port, verbose)
        self.reconnect = reconnect

    def send(self, jable_data):
        (host,port,verbose) = self._data

        strdata = json.dumps(jable_data)        
        try:
            self.sock.sendall( strdata.encode() )
            ConnectionAbortedError#if thread-in-thread. ..?
            print('sent',strdata[:20]) if verbose else 1
        except ConnectionResetError:
            print('server disconnected:',self.sock.getsockname()) if verbose else 1
            if self.reconnect:
                self.sock = get_client(host, port, verbose)

        except ConnectionAbortedError:
            print('server aborted :',self.sock.getsockname()) if verbose else 1
            if self.reconnect:
                self.sock = get_client(host, port, verbose)

















#====below you not wanna use this.. QueueRecv and Sender is fine.
def client_recv_forever(host,port, put_function=None, verbose=False):
    if put_function == None:
        put_function = lambda x:print('put',data)

    sock = get_client(host,port, verbose)

    while True:
        try:
            data = sock.recv(2**13)#12=4096
        except ConnectionResetError:
            print('server disconnected..') if verbose else 1
            sock = get_client(host,port,verbose)
            continue
        if not data:#also server disconnected. b'' will no response. lets assume disconnected.
            print('recved empty.. seemd disconn..') if verbose else 1
            sock = get_client(host,port,verbose)
            continue
        strdata = data.decode()
        #print(strdata,'what')#["hello"]["hello"]
        try:
            parsed_data = json.loads(strdata)
        except json.decoder.JSONDecodeError:
            print('seems the loop is too fast, and server resetted.') if verbose else 1
            #raise TypeError
            continue
        
        put_function(parsed_data)        

#============
def _test_clinet_without_class():
    th = threading.Thread( target = client_recv_forever, args=[HOST,PORT])
    th.start()
    print('main thread sleep')
    time.sleep(40)

#_test_clinet_without_class()



#=================================
class QueueClient:
    """open client socket, like QueueServer. """
    def __init__(self, host=HOST, port=PORT, verbose=False):
        queue = Queue()
        def put_function(data):
            queue.put(data)


        cs = ClientSocket(host,port,verbose)

        th = threading.Thread( target = client_recv_forever, args=[HOST,PORT, put_function, verbose])
        th.start()
        self.queue = queue

    def get_all(self):
        queue = self.queue
        while not queue.empty():
            yield queue.get()

#==================
def _qctest():
    q = QueueClient(verbose = True)

    while True:
        for i in q.get_all():
            print(i)
        time.sleep(2)

#_qstest()



























#===========================
#for history.


#portdog = Portdog(host,port, queue)#whatever connected, gets and puts to queue.

#finally!
#portqueue = PortQueue(host,port)
#portqueue.get_all()


# class PortQueue:
#     def __init__(self, host=HOST, port=PORT):
#         queue = Queue()
#         self.queue = queue
#         def putter(data):
#             queue.put(data)
        
#         thread_run(putter, host,port)
    
#     def get_all(self):
#         queue = self.queue
#         while not queue.empty():
#             yield queue.get()

# def pqtest():
#     a = PortQueue()
#     while True:
#         for i in a.get_all():
#             print(i)
#         time.sleep(1)


# 'accept'
#  'bind'
#  'close'
#  'connect'
#  'connect_ex'
#  'detach'
#  'dup'
#  'family'
#  'fileno'
#  'get_inheritable'
#  'getblocking'
#  'getpeername'
#  'getsockname'
#  'getsockopt'
#  'gettimeout'
#  'ioctl'
#  'listen'
#  'makefile'
#  'proto'
#  'recv'
#  'recv_into'
#  'recvfrom'
#  'recvfrom_into'
#  'send'
#  'sendall'
#  'sendfile'
#  'sendto'
#  'set_inheritable'
#  'setblocking'
#  'setsockopt'
#  'settimeout'
#  'share'
#  'shutdown'
#  'timeout'
#  'type'




#recv {1:1}{2:2} json parse err, we can }{.replace(),,but not do that much!



#print(addr)#('192.168.0.47', 3471)
#laddr=('192.168.0.47', 30020), raddr=('192.168.0.47', 2967)>



#seems bad and data byte+btyte problem.
# class ServerSocket:
#     def __init__(self, host,port, verbose=False):
#         self.host = host
#         self.port = port
#         self.verbose = verbose
#         self.server = get_server(self.host,self.port,self.verbose)
#     def recv_loads(self):
#         sock = self.server
#         host = self.host
#         port = self.port
#         verbose = self.verbose

#         while True:        
#             try:
#                 data = sock.recv(2**13)
#             except ConnectionResetError:
#                 print('a client disconnected') if verbose else 1
#                 #sock = #we just finish here.. break ..no!
#                 sock = get_server(host,port,verbose)

#             if not data:#connection end
#                 print('a client connection end') if verbose else 1
#                 sock = get_server(host,port,verbose)
            
#             strdata = data.decode()        
#             try:
#                 parsed_data = json.loads(strdata)                
#             except json.decoder.JSONDecodeError:
#                 print('json decode failed:',data) if verbose else 1
#                 pass
#             break
        
#         self.server = sock
#         return parsed_data

# s = ServerSocket(HOST,PORT,True)
# while True:
#     data = s.recv_loads()
#     print(data)
#     time.sleep(2)




# class ClientSocket:
#     def __init__(self, host,port, verbose=False):
#         self.host = host
#         self.port = port
#         self.verbose = verbose
#         self.client = get_client(self.host,self.port,self.verbose)
#     def recv_loads(self):
#         sock = self.client
#         host = self.host
#         port = self.port
#         verbose = self.verbose

#         while True:
#             try:
#                 data = sock.recv(2**13)#12=4096
#             except ConnectionResetError:
#                 print('server disconnected..') if verbose else 1
#                 sock = get_client(host,port,verbose)
#                 continue
#             if not data:#also server disconnected. b'' will no response. lets assume disconnected.
#                 print('recved empty.. seemd disconn..') if verbose else 1
#                 sock = get_client(host,port,verbose)
#                 continue
#             strdata = data.decode()
#             #print(strdata,'what')#["hello"]["hello"]
#             try:
#                 parsed_data = json.loads(strdata)
#             except json.decoder.JSONDecodeError:
#                 print('seems the loop is too fast, and server resetted.') if verbose else 1
#                 #raise TypeError
#                 continue
#             break

#         self.client = sock
#         return parsed_data