import time
import random
import uuid

from queue import Queue

import math


class Simulator:
	def __init__(self, view_control):
		self.view_control = view_control
		self.time = 0		
	def run(self, world):
		self.time = time.perf_counter()
		while True:
			tnow = time.perf_counter()
			dt = tnow - self.time
			self.time = tnow
			
			ninputs = []
			inputs = self.view_control.get_inputs()
			for i in inputs:
				key = i['abskey']
				value = i['value']
				ni = Input('5549',key,value)
				ninputs.append(ni)

			inputs = ninputs
			world.input(inputs)
			#world.update(dt)
			draws = world.draw()

			self.view_control.draw(draws)
			#time.sleep(0.101)#this causes jitter

class World:
	def __init__(self):
		self.actorDict = {}
	def add(self,actor):
		self.actorDict[actor.id] = actor
	def remove(self,actor):
		if actor.id in self.actorDict:
			self.actorDict.pop(actor.id)
	def get(self,id):
		return self.actorDict.get(id)

	def input(self,inputs):
		for i in inputs:
			targetid = i.target
			if targetid in self.actorDict:
				actor = self.actorDict[targetid]
				actor.input(i)
		
	def update(self,dt):
		for id,actor in self.actorDict.items():
			actor.update(dt)	
	def draw(self):
		draws = {}
		for id,actor in self.actorDict.items():
			draw_data = {'pos':actor.pos}
			draws[actor.id] = draw_data
		return draws


keymap_general={
	'F':'jump',
	'W':'move_forward*1.0',
	'MOUSE_X': 'setx*1',
	'MOUSE_Y': 'sety*-1',
}

class Actor:
	count = 0
	def __init__(self):
		self.id = str(uuid.uuid4()).replace('-','_')
		self.name = f"{self.__class__.__name__}_{Actor.count}"
		Actor.count += 1
		#===
		#self.keymap = {'f':lambda actor,key,value:print('-input:',actor,key,value)}
		self.keymap = keymap_general
		self.pos = [0,0,0]
		#===
		self.t = 0
	def __repr__(self):
		return f"{self.name}"

	def update(self,dt):
		self.t+=dt
		x = math.cos(self.t)
		y = math.sin(self.t)
		self.pos[0:2] = x,y

	def input(self,i):
		if i.key in self.keymap:
			funcname = self.keymap[i.key]
			
			if '*' in funcname:
				funcname, mul = funcname.split('*')
				mul = float(mul)
			else:
				mul = None
			if hasattr(self, funcname):
				func = getattr(self,funcname)
				if mul == None:
					if i.value>0:
						func()
				else:
					func(i.value*mul)

	def jump(self):
		print('jump!')
	def setx(self, x):
		self.pos[0] = x
	def sety(self, y):
		self.pos[1] = y


class Input:
	#__slots__ = ['target','key','value']
	def __init__(self, target, key,value,):
		self.target = target
		self.key = key
		self.value = value
	def __repr__(self):
		return f"{self.target}:{self.key},{self.value}"

def actorkeytest():
	a = Actor()
	i = Input(None,'f', 1.0)
	a.input(i)

actorkeytest()

def worldupdatetest():
	w = World()
	a = Actor()
	w.add(a)

	i = Input(a.id,'f',1.0)
	w.input([i])
	w.update(0.1)
	d = w.draw()
	print(d)

worldupdatetest()


class Inputman:
	def __init__(self):
		self.queue = Queue()

	def get(self):
		queue = self.queue
		inputs = []
		while not queue.empty():
			i = queue.get()
			inputs.append(i)
		return inputs

from postview import Window

import json

def simtest():
	window = Window()
	s = Simulator(window)

	w = World()
	a = Actor()
	a.id = '5549'
	w.add(a)
	s.run(w)

simtest()

