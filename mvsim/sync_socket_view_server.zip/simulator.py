from port import Port

class World:
    def __init__(self):
        self.tick=0
    def input(self,inputs):
        print(inputs)
    def draw(self):
        return str(self.tick)
    def update(self):
        self.tick+=1

def sim_loop():
    port = Port()
    port.connect()

    world = World()
    for i in range(5):
        print('getting')
        inputs = port.get()
        print('getdone')
        world.input(inputs)

        world.update()

        outputs = world.draw()
        print('putting')
        port.put(outputs)
        port.put('')
        print('putdone')

sim_loop()