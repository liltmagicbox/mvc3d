import socket
import threading

#class Client:
    #def __init__(self, host='localhost', port=30020):


host = 'localhost'
port = 30030

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect( (host,port) )


data = client.recv(4096)
print(data)

#client.sendall( '33'.zfill(64).encode() )

bdata = 'hellddddddddddddddddddddddddddddddddddEND'.encode()
client.sendall( bdata )

class Client:
    def put(self):
        1
    def get(self):
        1
