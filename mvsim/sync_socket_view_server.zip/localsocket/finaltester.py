from portroyal import Port

a = Port()
a.run()

while True:
	a.put('this is from server')
	d = a.get()
	print(d)