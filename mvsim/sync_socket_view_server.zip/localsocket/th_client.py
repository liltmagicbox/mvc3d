import socket

#(255).to_bytes(4, byteorder='big',signed = False)
#int.from_bytes(b, 'big')

host='localhost'
port=30030

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect( (host,port) )

sock = client


# port.put(inputs)
# draws = port.get()
# bcast(draws)


# inputs = port.get()
# world.input(inputs)

# world.update(dt)

# draws = world.draw()
# port.put(draws)

#=============client side
def recvall(sock,n):
    maxbuffer = 2**10
    
    data = bytearray()
    while len(data) < n:
        remain_bytes = n-len(data)
        recvlen = maxbuffer if remain_bytes>maxbuffer else remain_bytes
        packet = sock.recv(recvlen)
        if not packet:
            return None
        data.extend(packet)
    return data

def get():
    dlen = int(sock.recv(16).decode())
    data = recvall(sock,dlen)
    return data

def put(data):
    if type(data)==str:
        data = data.encode()
    dlen = str(len(data)).zfill(16).encode()
    sock.sendall(dlen)
    sock.sendall(data)

import time

while True:
    inputs = get()
    print(inputs)
    
    time.sleep(1)

    put('thisisdata')

#=================================
#bdata = 'get'.zfill(16).encode()
#sock.sendall(bdata)

#get return
bdata = sock.recv(16)
print(bdata)
dlen = int(bdata.decode())
print(dlen)

bdata = sock.recv(dlen)
data = bdata.decode()
print(data)





import time
time.sleep(100)


def return_get(sock, data):
    dlen = data

def get_len(sock):
    sock.sendall('get'.encode())
    rawlen = sock.recv(16)
    dlen = int(rawlen.decode())
    return dlen


def get(sock):
    sock.sendall('get'.encode())
    dlen = int( sock.recv(4).decode() )
    print(dlen)
    return recvall(sock, dlen)

def recvall(sock, n):
    maxbuffer = 2**10
    
    data = bytearray()
    while len(data) < n:
        remain_bytes = n-len(data)
        recvlen = maxbuffer if remain_bytes>maxbuffer else remain_bytes
        packet = sock.recv(recvlen)
        if not packet:
            return None
        data.extend(packet)
    return data

def put(sock,data):
    sock.sendall('put'.encode())
    blen = str(len(data)).encode()
    sock.sendall(blen)
    sock.sendall(data.encode())
                

import time
while True:
    get(client)
    put(client, 'thisisdata')
    time.sleep(1)



print(data,'recv')


bdata = 'worldviewx'.encode()
blen = len(bdata)

client.sendall(f'view{blen}'.encode())
client.sendall(bdata)

time.sleep(3)
#client.close()

"""
1. server recvs.
2. client sends init msg (input,output..), recvs
3. server parse msg, sends pre-data
4. client recvs pre-data, recvs.
5. server sends data
6. client recvs data
"""

