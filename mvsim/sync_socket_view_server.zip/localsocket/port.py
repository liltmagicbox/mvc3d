import socket


def ma():
	port = port.run()
	while True:
		#keys = queue.get()
		port.put(keys)
		views = port.get()#halt
		#bcast(views)


class Port:
	def __init__(self, host='localhost', port=30030):
		self.host = host
		self.port = port
		self.conn = None

	def run(self):
		server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		server_socket.bind( (host,port) )
		server_socket.listen()
		conn, addr = server_socket.accept()
		
		while True:
			header = conn.recv(8).decode()
		    if header == 'get':
		    	data
		        conn.sendall(data)
		    
		    elif header == 'put':
		        views = []
		        while True:
		            data = conn.recv(4096)
		            views.append(data)
		            if not data:
		                break
		        strdata = b''.join(views).decode()
		        print(strdata)
		conn.close()
		server_socket.close()
		self.conn = None



	def connect(self):
		client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
		client.connect( (self.host,self.port) )
		self.conn = client

	def put(self,data):
		"""server put first"""
		bdata = data.encode()
		self.conn.sendall( bdata )
		print(bdata,'sent')
	def get(self):
		"""client get first"""
		packets = []
		while True:
			data = self.conn.recv(2048)
			print(data)
			if not data:
				break
			packets.append(data)
		data_str = b''.join(packets).decode()
		return data_str
