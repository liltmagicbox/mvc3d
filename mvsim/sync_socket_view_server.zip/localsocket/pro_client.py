import socket

host='localhost'
port=30030

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect( (host,port) )


client.sendall('key'.encode())
data = client.recv(4096)
print(data)




client.sendall('view'.encode())


import random

class M:
    def __init__(self):
        self.age=random.randint(0,90)
        self.position = random.randint(0,50)

massdata=[]
for i in range(100000):
    m=M()
    massdata.append( m.__dict__ )

import json
viewdata = json.dumps(massdata)

client.sendall(viewdata.encode())

exit()
