from portroyal import Port

import time

a = Port()
a.connect()

while True:
	d = a.get()
	print(d)
	time.sleep(1)
	a.put('client data')