import socket

def recvall(sock,n):
    maxbuffer = 2**13#20max. 12 4096
    
    data = bytearray()
    while len(data) < n:
        remain_bytes = n-len(data)
        recvlen = maxbuffer if remain_bytes>maxbuffer else remain_bytes
        packet = sock.recv(recvlen)
        if not packet:
            return None
        data.extend(packet)
    return data

def get(sock):
    """data is str"""
    dlen = int(sock.recv(16).decode())
    data = recvall(sock,dlen)    
    return data.decode()

def put(sock,data):
    """data is str"""
    data = data.encode()
    dlen = str(len(data)).zfill(16).encode()
    sock.sendall(dlen)
    sock.sendall(data)
    


class Port:    
    def __init__(self, host='localhost', port=30030):
        self.host = host
        self.port = port
        self.server_socket = None
        self.sock = None
    
    def run(self):
        """is server. put first?"""
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind( (self.host,self.port) )
        server_socket.listen()
        conn, addr = server_socket.accept()
        
        self.sock = conn
        self.server_socket = server_socket

    def accept_again(self):
        self.sock.close()
        if self.server_socket:            
            conn, addr = self.server_socket.accept()
            self.sock = conn
        else:
            client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            client.connect( (self.host,self.port) )
            self.sock = client

    def connect(self):
        """is client. get first?"""
        client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        client.connect( (self.host,self.port) )
        ConnectionRefusedError
        self.sock = client

    def put(self,data):        
        try:
            put(self.sock,data)
        except ConnectionResetError:
            self.accept_again()

    def get(self):
        try:
            return get(self.sock)
        except ConnectionResetError:
            self.accept_again()


def server():
    a = Port()
    a.run()
    while True:
        a.put('this is from server')
        d = a.get()
        print(d)

def client():
    import time

    a = Port()
    a.connect()

    while True:
        d = a.get()
        print(d)
        time.sleep(1)
        a.put('client data')