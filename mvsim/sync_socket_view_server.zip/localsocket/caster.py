
#broadcasting server.
#has local socket, can connect simulator.
#put/get data.
#main thread is ws server, local socket is threaded.

class Caster:
	def __init__(self, host = 'localhost', port = 30020, socket_port = 20020):
		self.socket_port = socket_port
