import socket
import threading

host='localhost'
port=30030

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect( (host,port) )

#import time



# client.sendall('weneedkey'.encode())
# data = client.recv(2048)
# print(data)


import random

class M:
	def __init__(self):
		self.age=random.randint(0,90)
		self.position = random.randint(0,50)

massdata=[]
for i in range(100000):
	m=M()
	massdata.append( m.__dict__ )

import json
viewdata = json.dumps(massdata)


client.sendall(viewdata.encode())

#data = client.recv(2048)#this prevents sending b''.
#print(data)

exit()

# data = client.recv(2048)	
# print(data)
# data = client.recv(2048)	
# print(data)
# exit()

while True:
	data = client.recv(2048)	
	print(data,end='')
	if not data:
		break


# for i in range(5):
# 	bdata = str(i).encode()+'data'.encode()
# 	client.sendall( bdata )
# 	while True:
# 		data = client.recv(4096)
# 		print(data,'recv')
# 		if not data:
# 			print('no')
# 			break

