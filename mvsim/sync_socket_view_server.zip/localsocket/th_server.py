import socket


host='localhost'
port=30030

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind( (host,port) )
server_socket.listen()

conn, addr = server_socket.accept()

sock = conn


def recvall(sock,n):
    maxbuffer = 2**10
    
    data = bytearray()
    while len(data) < n:
        remain_bytes = n-len(data)
        recvlen = maxbuffer if remain_bytes>maxbuffer else remain_bytes
        packet = sock.recv(recvlen)
        if not packet:
            return None
        data.extend(packet)
    return data

def get():
    dlen = int(sock.recv(16).decode())
    data = recvall(sock,dlen)
    return data

def put(data):
    if type(data)==str:
        data = data.encode()
    dlen = str(len(data)).zfill(16).encode()
    sock.sendall(dlen)
    sock.sendall(data)


while True:
    put('inputdata')
    draws = get()
    print(draws)

#=================================
bdata = sock.recv(16)

data = 'maxdata'

bdata = str(len(data)).encode()
sock.sendall(bdata)

bdata = data.encode()
sock.sendall(bdata)


def put(sock, data):
    sock.sendall()



import time
time.sleep(100)

class Server:
    def __init__(self, host='localhost', port=30030):        
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind( (host,port) )
        server_socket.listen()
        
        conn, addr = server_socket.accept()
        self.conn = conn
    
    def run(self):
        while True:
            strdata = self.conn.recv(4).decode()
            #print(strdata)
            
            if strdata == 'get':
                strdata = 'fulldataall'

                blen = str(len(strdata)).encode()
                self.conn.sendall(blen)
                self.conn.sendall(strdata.encode())
                #self.conn.send(f"{dlen}".encode())
            elif strdata == 'put':
                blen = int( self.conn.recv(16).decode() )
                print(blen)            
                strdata = self.conn.recv(blen).decode()
                print(strdata)            

                        

    def put(self,data):
        1
    def get(self):
        strdata = self.conn.recv(1024).decode()
        if strdata == 'key':
            keys = '[1,2,3]'.encode()
            self.conn.sendall(keys)
        elif 'view' in strdata:
            print(strdata)
            strdata
            buffersize=2
            data=[]
            while True:
                chunk = self.conn.recv(buffersize)
                print(chunk)
                data.append(chunk)                
            fulldata = b''.join(data)
            return fulldata

s = Server()
s.run()

exit()

#keys = [1,2,3]
#s.put(keys)

import time

while True:
    x = s.get()
    print(x)
    time.sleep(1)










while True:
    data = conn.recv(1024)
    if not data:
        break
    
    if data.decode() == 'input':
        1



class Server:
    def put(self,data):
        1
    def get(self):

        return data

    def __init__(self, host='localhost', port=30030):
        def runserver(connected):
            server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server_socket.settimeout(1)
            server_socket.bind( (host,port) )            
            
            server_socket.listen()
            conn, addr = server_socket.accept()
            connected = True

            while True:
                header = conn.recv(8).decode()
                if not header:
                    break
                if header == 'key':
                    conn.sendall('keykeykeykeykeykeykeykeykey'.encode())
                
                elif header == 'view':
                    views = []
                    while True:
                        data = conn.recv(4096)
                        views.append(data)
                        if not data:
                            break
                    strdata = b''.join(views).decode()
                    print(strdata)
        
        self.connected = False
        th = threading.Thread( target = runserver, args=(self.connected,) )
        th.start()

#s = Server()

# port = Port()
# port.run()

# while True:
#     keys = []
#     while not queue.empty():
#         key = queue.get()
#         keys.append(key)
#     port.put( keys)
    
#     view = port.get()
#     # if not view:
#     #     view = []
#     cast(view)