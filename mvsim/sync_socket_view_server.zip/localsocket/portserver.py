# from port import Port

# a= Port()
# a.run()

import socket
import threading

host='localhost'
port=30030

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind( (host,port) )

server_socket.listen()
conn, addr = server_socket.accept()
print('connected', addr)



while True:
	try:
		bytedata = []
		while True:
			data = conn.recv(2**12)
			if not data:
				break
			bytedata.append(data)
		fullbyte = b''.join(bytedata)
		strdata = fullbyte.decode()

		import json
		ddict = json.loads(strdata)
		print(ddict)


		command = data.decode()
		if command == 'weneedkey':
			data = 'key values'.encode()

		elif command == 'viewdata':
			data = 'we got view'.encode()
		else:
			print(command)
			data = 'wedonnow'.encode()

		conn.sendall(data)

		#conn.sendall( b'server sent data')
		#conn.sendall( b'echo '+data )
	except ConnectionAbortedError:
		print('disconnected')
		server_socket.listen()
		conn, addr = server_socket.accept()
		#break
	except ConnectionResetError:
		#print('reset')
		server_socket.listen()
		conn, addr = server_socket.accept()
		print('connected', addr)
		#break




conn.close()
server_socket.close()