import socket

host='localhost'
port=30030

server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server_socket.bind( (host,port) )

server_socket.listen()
conn, addr = server_socket.accept()
print('connected', addr)


while True:
    header = conn.recv(8).decode()
    if not header:
        break
    if header == 'key':
        conn.sendall('keykeykeykeykeykeykeykeykey'.encode())
    
    elif header == 'view':
        views = []
        while True:
            data = conn.recv(4096)
            views.append(data)
            if not data:
                break
        strdata = b''.join(views).decode()
        print(strdata)