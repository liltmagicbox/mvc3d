import threading
import socket
import json
from queue import Queue
import time

HOST = socket.gethostbyname(socket.gethostname())
PORT = 30020


#======= this reconnects even server's state. if disconnected, recvs data=''.if fail connection,CRE.
#whatever, queue will get what's came from. recv halts, cpu power safe.

host,port = HOST,PORT

class PortQueueServer:
    """open server socket, run thread, if new conn, put to queue."""
    def __init__(self, host=HOST, port=PORT, verbose=False):
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind( (host,port) )
        server_socket.listen()

        queue = Queue()

        def put_function(data):
            queue.put(data)

        verbose = verbose

        th = threading.Thread( target = server_recv_forever, args=[server_socket,put_function, verbose])
        th.start()

        self.queue = queue
    def get_all(self):
        queue = self.queue
        while not queue.empty():
            yield queue.get()


def server_recv_forever(server_socket, put_function, verbose):
    def server_listen():
        conn, addr = server_socket.accept()
        print('a client connected') if verbose else 1
        return conn

    sock = server_listen()

    while True:        
        try:
            data = sock.recv(2**13)
        except ConnectionResetError:
            print('a client disconnected') if verbose else 1
            #sock = #we just finish here.. break ..no!
            sock = server_listen()

        if not data:#connection end
            print('a client connection end') if verbose else 1
            sock = server_listen()
        
        strdata = data.decode()        
        try:
            parsed_data = json.loads(strdata)
            put_function(parsed_data)
        except json.decoder.JSONDecodeError:
            print('json decode failed:',data) if verbose else 1
            pass


def _test_server_without_class():
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    server_socket.bind( (host,port) )
    server_socket.listen()

    def put_function(data):
        print(data,'incoming')

    verbose = True

    th = threading.Thread( target = server_recv_forever, args=[server_socket,put_function, verbose])
    th.start()

    print('main thread sleep')
    time.sleep(40)

#_test_server_without_class()

print('end')
exit()
#print(addr)#('192.168.0.47', 3471)
#laddr=('192.168.0.47', 30020), raddr=('192.168.0.47', 2967)>



def recv_forever(put_function, host, port, verbose):

    def connect():
        server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        server_socket.bind( (host,port) )
        server_socket.listen()        

        tryagain = True
        while tryagain:
            try:
                conn, addr = server_socket.accept()
                tryagain = False                
            except ConnectionRefusedError:
                print('reconnecting..') if verbose else 1
                continue
        print('connected!') if verbose else 1
        return conn

    sock = connect()

    while True:
        try:
            data = sock.recv(2**13)#12=4096
        except ConnectionResetError:
            sock = connect()
            continue
        if not data:#also server disconnected. b'' will no response. lets assume disconnected.
            sock = connect()
            continue
        strdata = data.decode()
        #print(strdata,'what')#["hello"]["hello"]
        try:
            parsed_data = json.loads(strdata)
        except json.decoder.JSONDecodeError:
            print('seems the loop is too fast, and server resetted.')
            raise TypeError
        
        put_function(parsed_data)        

recv_forever(lambda x:print(x,'recv'), host,port,True)
exit()

#============
def thread_run(data_dealer, host,port, verbose = False):
    th = threading.Thread( target = recv_forever, args=[data_dealer, host,port, verbose])
    th.start()



#===========================
def main():
    queue = Queue()
    def getter(data):
        queue.put(data)

    thread_run(getter, HOST,PORT, verbose =True)

    while True:
        while not queue.empty():
            g = queue.get()
            print(g)
        else:#else of while!
            print('/',end='')
        time.sleep(0.1)

if __name__ == '__main__':
    main()




#portdog = Portdog(host,port, queue)#whatever connected, gets and puts to queue.

#finally!
#portqueue = PortQueue(host,port)
#portqueue.get_all()


class PortQueue:
    def __init__(self, host=HOST, port=PORT):
        queue = Queue()
        self.queue = queue
        def putter(data):
            queue.put(data)
        
        thread_run(putter, host,port)
    
    def get_all(self):
        queue = self.queue
        while not queue.empty():
            yield queue.get()

def pqtest():
    a = PortQueue()
    while True:
        for i in a.get_all():
            print(i)
        time.sleep(1)

 # 'accept'
 #  'bind'
 #  'close'
 #  'connect'
 #  'connect_ex'
 #  'detach'
 #  'dup'
 #  'family'
 #  'fileno'
 #  'get_inheritable'
 #  'getblocking'
 #  'getpeername'
 #  'getsockname'
 #  'getsockopt'
 #  'gettimeout'
 #  'ioctl'
 #  'listen'
 #  'makefile'
 #  'proto'
 #  'recv'
 #  'recv_into'
 #  'recvfrom'
 #  'recvfrom_into'
 #  'send'
 #  'sendall'
 #  'sendfile'
 #  'sendto'
 #  'set_inheritable'
 #  'setblocking'
 #  'setsockopt'
 #  'settimeout'
 #  'share'
 #  'shutdown'
 #  'timeout'
 #  'type'
