import threading
import socket
import json
from queue import Queue
import time

HOST = socket.gethostbyname(socket.gethostname())
PORT = 30020


def get_server(host=HOST,port=PORT, verbose=False):
    server_socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    while True:
        try:
            server_socket.bind( (host,port) )#OSError: [WinError 10048]
            break
        except OSError as err:
            print(err) if verbose else 1
            if '10048' in str(err):
                raise Exception('PORT occupied already')
            break
    server_socket.listen()
    
    print('accepting..') if verbose else 1
    conn, addr = server_socket.accept()
    print('client connected') if verbose else 1
    return conn

#======= this reconnects even server's state. if disconnected, recvs data=''.if fail connection,CRE.
#whatever, queue will get what's came from. recv halts, cpu power safe.

def server_recv_forever(host,port, put_function=None, verbose=False):
    if put_function == None:
        put_function = lambda x:print('put',data)

    sock = get_server(host,port, verbose)

    while True:        
        try:
            data = sock.recv(2**13)
        except ConnectionResetError:
            print('client disconnected') if verbose else 1
            #sock = #we just finish here.. break ..no!
            sock = get_server(host,port,verbose)

        if not data:#connection end
            print('client connection end') if verbose else 1
            sock = get_server(host,port,verbose)
        
        strdata = data.decode()        
        try:
            parsed_data = json.loads(strdata)
            put_function(parsed_data)
        except json.decoder.JSONDecodeError:
            print('json decode failed:',data) if verbose else 1
            pass

#==================
def _test_server_without_class():
    th = threading.Thread( target = server_recv_forever, args=[HOST,PORT])
    th.start()
    
    print('main thread sleep')
    time.sleep(40)

#_test_server_without_class()

#print(addr)#('192.168.0.47', 3471)
#laddr=('192.168.0.47', 30020), raddr=('192.168.0.47', 2967)>



class QueueServer:
    """open server socket, run thread, if new conn, put to queue."""
    def __init__(self, host=HOST, port=PORT, verbose=False):
        queue = Queue()
        def put_function(data):
            queue.put(data)
        th = threading.Thread( target = server_recv_forever, args=[HOST,PORT, put_function, verbose])
        th.start()
        self.queue = queue

    def get_all(self):
        queue = self.queue
        while not queue.empty():
            yield queue.get()

#==================
def _qstest():
    q = QueueServer(verbose = True)

    while True:
        for i in q.get_all():
            print(i)
        time.sleep(2)

_qstest()






















#======================== client version


def get_client(host=HOST,port=PORT, verbose=False):        
    client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    while True:
        try:
            client.connect( (host,port) )
            break
        except ConnectionRefusedError:
            print('reconnecting..') if verbose else 1
            continue
    print('connected!') if verbose else 1
    return client


def client_recv_forever(host,port, put_function=None, verbose=False):
    if put_function == None:
        put_function = lambda x:print('put',data)

    sock = get_client(host,port, verbose)

    while True:
        try:
            data = sock.recv(2**13)#12=4096
        except ConnectionResetError:
            print('server disconnected..') if verbose else 1
            sock = get_client(host,port,verbose)
            continue
        if not data:#also server disconnected. b'' will no response. lets assume disconnected.
            print('recved empty.. seemd disconn..') if verbose else 1
            sock = get_client(host,port,verbose)
            continue
        strdata = data.decode()
        #print(strdata,'what')#["hello"]["hello"]
        try:
            parsed_data = json.loads(strdata)
        except json.decoder.JSONDecodeError:
            print('seems the loop is too fast, and server resetted.') if verbose else 1
            #raise TypeError
            continue
        
        put_function(parsed_data)        

#============
def _test_clinet_without_class():
    th = threading.Thread( target = client_recv_forever, args=[HOST,PORT])
    th.start()
    print('main thread sleep')
    time.sleep(40)

#_test_clinet_without_class()



#=================================
class QueueClient:
    """open client socket, like QueueServer. """
    def __init__(self, host=HOST, port=PORT, verbose=False):
        queue = Queue()
        def put_function(data):
            queue.put(data)


        cs = ClientSocket(host,port,verbose)

        th = threading.Thread( target = client_recv_forever, args=[HOST,PORT, put_function, verbose])
        th.start()
        self.queue = queue

    def get_all(self):
        queue = self.queue
        while not queue.empty():
            yield queue.get()

#==================
def _qctest():
    q = QueueClient(verbose = True)

    while True:
        for i in q.get_all():
            print(i)
        time.sleep(2)

#_qstest()
















#===========================
#for history.

#recv {1:1}{2:2} json parse err, we can }{.replace(),,but not do that much!

#portdog = Portdog(host,port, queue)#whatever connected, gets and puts to queue.

#finally!
#portqueue = PortQueue(host,port)
#portqueue.get_all()


# class PortQueue:
#     def __init__(self, host=HOST, port=PORT):
#         queue = Queue()
#         self.queue = queue
#         def putter(data):
#             queue.put(data)
        
#         thread_run(putter, host,port)
    
#     def get_all(self):
#         queue = self.queue
#         while not queue.empty():
#             yield queue.get()

# def pqtest():
#     a = PortQueue()
#     while True:
#         for i in a.get_all():
#             print(i)
#         time.sleep(1)


# 'accept'
#  'bind'
#  'close'
#  'connect'
#  'connect_ex'
#  'detach'
#  'dup'
#  'family'
#  'fileno'
#  'get_inheritable'
#  'getblocking'
#  'getpeername'
#  'getsockname'
#  'getsockopt'
#  'gettimeout'
#  'ioctl'
#  'listen'
#  'makefile'
#  'proto'
#  'recv'
#  'recv_into'
#  'recvfrom'
#  'recvfrom_into'
#  'send'
#  'sendall'
#  'sendfile'
#  'sendto'
#  'set_inheritable'
#  'setblocking'
#  'setsockopt'
#  'settimeout'
#  'share'
#  'shutdown'
#  'timeout'
#  'type'






#seems bad and data byte+btyte problem.
# class ServerSocket:
#     def __init__(self, host,port, verbose=False):
#         self.host = host
#         self.port = port
#         self.verbose = verbose
#         self.server = get_server(self.host,self.port,self.verbose)
#     def recv_loads(self):
#         sock = self.server
#         host = self.host
#         port = self.port
#         verbose = self.verbose

#         while True:        
#             try:
#                 data = sock.recv(2**13)
#             except ConnectionResetError:
#                 print('a client disconnected') if verbose else 1
#                 #sock = #we just finish here.. break ..no!
#                 sock = get_server(host,port,verbose)

#             if not data:#connection end
#                 print('a client connection end') if verbose else 1
#                 sock = get_server(host,port,verbose)
            
#             strdata = data.decode()        
#             try:
#                 parsed_data = json.loads(strdata)                
#             except json.decoder.JSONDecodeError:
#                 print('json decode failed:',data) if verbose else 1
#                 pass
#             break
        
#         self.server = sock
#         return parsed_data

# s = ServerSocket(HOST,PORT,True)
# while True:
#     data = s.recv_loads()
#     print(data)
#     time.sleep(2)




# class ClientSocket:
#     def __init__(self, host,port, verbose=False):
#         self.host = host
#         self.port = port
#         self.verbose = verbose
#         self.client = get_client(self.host,self.port,self.verbose)
#     def recv_loads(self):
#         sock = self.client
#         host = self.host
#         port = self.port
#         verbose = self.verbose

#         while True:
#             try:
#                 data = sock.recv(2**13)#12=4096
#             except ConnectionResetError:
#                 print('server disconnected..') if verbose else 1
#                 sock = get_client(host,port,verbose)
#                 continue
#             if not data:#also server disconnected. b'' will no response. lets assume disconnected.
#                 print('recved empty.. seemd disconn..') if verbose else 1
#                 sock = get_client(host,port,verbose)
#                 continue
#             strdata = data.decode()
#             #print(strdata,'what')#["hello"]["hello"]
#             try:
#                 parsed_data = json.loads(strdata)
#             except json.decoder.JSONDecodeError:
#                 print('seems the loop is too fast, and server resetted.') if verbose else 1
#                 #raise TypeError
#                 continue
#             break

#         self.client = sock
#         return parsed_data