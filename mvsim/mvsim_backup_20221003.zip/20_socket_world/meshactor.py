
from actor import Actor

class MeshActor(Actor):
	def __init__(self, geometry,material):
		super().__init__()
		self.geometry = geometry
		self.material = material
#a = MeshActor()

#But, MeshActorFactory will by (smid).
# storage, cache will split and reuse mat. fine.
# LOD shall be in same dir, dir is ID.
#lets:lod ->box,sphere, roundtables , not that convex. auto-created. ..course if not, load vertex, calc convexhull like..
#all data, just sets the folder, ID. thats all, so simple. all later. yeah.

# Mesh SKMesh Particle. need more??
#even cube, sphere kinds has ID, folder.
class ViewActor(Actor):
	def __init__(self, ID=0):
		super().__init__()
		self.viewid = ID


# Mesh
# VAO
# Mat
# Material
# Vertex
# Geometry
# Mesh(geo,mat)

# StaticMesh
# SKMesh

# #============ Mesh / MeshInstanced / SKMesh / Particles.

# Mesh(geo,mat)

#smd id xyz nxnynz, uv, weights.
class Geometry:
	""" position, and face indices. """
	def __init__(self, position, face, normal=None, uv=None):
		self.position = position
		self.face = face
		self.normal = normal
		self.uv = uv



class Material:
	def __init__(self):
		1


class Loader:
	def loadOBJ(self, fdir):
		1

