

keymap = {}
M_keymap = {
    'M_XY':'Jump',
    'M_X':'Jump',
    'M_Y':'Jump',
    'M_WHEEL':'Jump',    
    
    'M_LCLICK':'Jump',
    'M_RCLICK':'Jump',
    'M_WHEELCLICK':'Jump',

    'M_1':'Jump',
    'M_2':'Jump',
    'M_3':'Jump',

}

J_keymap = {
'J_A': 'Jump',
'J_B': 'Jump',
'J_X': 'Jump',
'J_Y': 'Jump',
'J_L1': 'Jump',
'J_L2': 'Jump',
'J_L3': 'Jump',
'J_R1': 'Jump',
'J_R2': 'Jump',
'J_R3': 'Jump',

#'J_DPAD': 'Jump',
'J_UP': 'Jump',
'J_DOWN': 'Jump',
'J_LEFT': 'Jump',
'J_RIGHT': 'Jump',

'J_LXY': 'Jump',
'J_LX': 'Jump',
'J_LY': 'Jump',

'J_RXY': 'Jump',
'J_RX': 'Jump',
'J_RY': 'Jump',
}
#RSTICKXY is too long.,
#or, J_LSTICK_XY ??
#or, J_LSTICK*XY ??

#direction
#position
#hand??
#
V_keymap = {
    'V_RXYZ':1,
    'V_RXYZ':1,
}

# J_LXY
# J_XY
# J_Analog
# J_DPAD is wsad
# LeftStick
# LeftAnalog









    