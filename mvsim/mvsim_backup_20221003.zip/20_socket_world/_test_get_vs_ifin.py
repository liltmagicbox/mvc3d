import timefor


a={1:11,2:22}


def ma():
	if 1 in a:
		v = a[1]
		return v
timefor.run(ma)

def ma():
	if 1 in a:
		v = a.get(1)
		return v
timefor.run(ma)


def ma():
	value = a.get(1)
	if value:
		a[3]=33
		return value
timefor.run(ma)

#6% difference!
#10ms for 100k. while simple for took 4ms.