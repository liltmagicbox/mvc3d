import uuid
import math
from interface import IWorld,IActor

#before we assume jump is jump(), while jump*1.0 shall be jump(value).
#but what if jump_but_with_value ?? i think same jump will be better.
#by that we can jump, with stick,more delicately.
#key Actions may be Capital..? usually since it shall not be in python. i think..
#..think something was similler before.. or itself.


keymap_general={
    'F':'Jump',
    'W':'move_forward*1.0',
    'M_X': 'setx*1',
    'M_Y': 'sety*-1',
}


def keymap_parse(actor,keymap,i):
    if isinstance(i,dict):
        key,value = i['key'],i['value']
    else:
        key,value = i.key, i.value

    if key in actor.keymap:
        funcname = actor.keymap[key]
        
        if '*' in funcname:
            funcname, mul = funcname.split('*')
            mul = float(mul)
        else:
            mul = None
        if hasattr(actor, funcname):
            func = getattr(actor,funcname)
            if mul == None:
                if value>0:
                    func()
            else:
                func(value*mul)


from physics import Physics

class Actor(IActor, Physics):
    _count = 0
    def __init__(self):
        self.id = str(uuid.uuid4()).replace('-','_')
        self.name = f"{self.__class__.__name__}_{Actor._count}"
        Actor._count += 1
        #===
        #self.keymap = {'f':lambda actor,key,value:print('-input:',actor,key,value)}
        self.keymap = keymap_general
        
        #===
        #self.pos = [0,0,0]
        self.physics = False
        Physics.__init__(self)
        #===
        self.t = 0
    def __repr__(self):
        return f"{self.name}"

    #======api
    def update(self,dt):
        self._update(dt)#-better.
        #Physics.update(self,dt)
        if self.physics:
            self._update_physics(dt)#-better.
    
    def input(self,i):
        keymap_parse(self, self.keymap, i)
    
    #=========internal
    def _update(self,dt):
        1
        # self.t+=dt
        # x = math.cos(self.t)*0.8
        # y = math.sin(self.t)*0.8
        # self.pos[0:2] = x,y

    #==========actions.
    def Jump(self, value=None):
        print('jump!')
    def setx(self, x):
        self.pos[0] = x
    def sety(self, y):
        self.pos[1] = y

def main():
    a=Actor()
    a.physics = True
    a.speed.set(1,0,0)
    a.gravity_scale = 1
    for i in range(300):
        a.update(0.01)
    print(a.pos,a.speed)
    a.input( {'key':'F', 'value':1.0} )



if __name__ == '__main__':
    main()







history = """

class _bad_shaped_Physics:
    #__slots__ = ['force','mass','acc','speed','pos']
    def __init__(self):
        self.force = Vec3(0,0,0)
        self.mass = 1
        self.acc = Vec3(0,0,0)
        self.speed = Vec3(0,0,0)
        self.pos = Vec3(0,0,0)
    def _update(self,dt):
        acc,speed,pos = self.acc,self.speed,self.pos
        #f = m*a, a=f/m.        
        acc_by_force = self.force/self.mass
        acc += acc_by_force *dt
        speed += acc * dt
        pos += speed * dt
        self.acc,self.speed,self.pos = acc,speed,pos

"""