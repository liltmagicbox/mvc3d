#https://github.com/totex/PyOpenGL_tutorials/blob/master/main.py

#import glfw

from glfw import _GLFWwindow as GLFWwindow
from glfw.GLFW import *
from OpenGL.GL import *
import OpenGL.GL.shaders
##from OpenGL.GL import shaders
import numpy


SCR_WIDTH = 800
SCR_HEIGHT = 600

class Window:
    def __init__(self, width,height,name):
        if not glfwInit():
            return
        glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4)
        glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3)
        glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE)
        glfwWindowHint(GLFW_DOUBLEBUFFER, GLFW_TRUE)#for vsync. we do d.buffer atleast!!
        #window = glfw.create_window(800, 600, "My OpenGL window", None, None)        

        window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "My OpenGL window", None, None)
        if not window:
            glfwTerminate()
            return
        glfwMakeContextCurrent(window)
        glEnable(GL_DEPTH_TEST)
        glClearColor(0.2, 0.3, 0.2, 1.0)
        
        # glfw: whenever the window size changed (by OS or user resize) this callback function executes
        def framebuffer_size_callback(window: GLFWwindow, width: int, height: int) -> None:
            # make sure the viewport matches the new window dimensions note that width and 
            # height will be significantly larger than specified on retina displays.
            glViewport(0, 0, width, height)
        glfwSetFramebufferSizeCallback(window, framebuffer_size_callback)
        
        #https://www.glfw.org/docs/3.3/group__input.html#gaa92336e173da9c8834558b54ee80563b
        glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED)#GLFW_CURSOR_NORMAL
        self.is_mouselock = True
        self.window = window

    def bind(self, inputmanager):
        self.inputmanager = inputmanager

        def key_callback(window, key, scancode, action, mods) -> None:
            #key == GLFW_KEY_ESCAPE: not here.
            #print(key, scancode, action, mods)
            #mods 1 2 4 LSH ctrl alt
            #scancode donno, action 0 1 2, 2is presseded
            if action==1 or action==2:
                value = 1
            else:
                value = 0
            kk = glfwGetKeyName(key, scancode)
            sk = glfwGetKeyScancode(key)
            #print(kk,'kkkkkkkk')
            #print(sk,'sssss')
            inputmanager.input(key,value,mods)

        def mouse_button_callback(window, button, action, mods) -> None:
            #print(button,action,mods)# 0 left 1 right 2 mid. 3,4 l/R thumb . action 0/1. fine. mod 1,2,4.
            mousekey={
            0:'M_LEFT',
            1:'M_RIGHT',
            2:'M_MIDDLE',
            }    
            key = mousekey.get(button)
            inputmanager.input(key,action,mods)            

        def mouse_callback(window: GLFWwindow, xpos: float, ypos: float) -> None:
            key = 'M_XY'
            inputmanager.input_axis(key, xpos,ypos)

        def scroll_callback(window: GLFWwindow, xoffset: float, yoffset: float) -> None:
            if yoffset>0:
                key = 'M_SCROLL_UP'
                value=1
            else:
                key = 'M_SCROLL_DOWN'
                value=0
            inputmanager.input(key, value)#for generalization [0-1]
        window = self.window
        glfwSetKeyCallback(window, key_callback)
        glfwSetMouseButtonCallback(window, mouse_button_callback)
        glfwSetCursorPosCallback(window, mouse_callback)
        glfwSetScrollCallback(window, scroll_callback)

    def run(self):
        window = self.window        
        timebefore=0
        while not glfwWindowShouldClose(window):
            timenow = glfwGetTime()
            dt = timenow-timebefore
            timebefore = timenow
            self.update(self,dt)

            #dbuffer True, use swapbuffer. interval0 if fullspeed test.
            #dbuffer False, use glFlush, the old way maybe.fine.
            #glfwSwapInterval(1)# 10 160ms tooslow, 1 16ms, 0 fastest
            glfwSwapBuffers(window)#requires dbuffer True.
            #glFlush()#when not using vsync #-- we found, flush returns anytime, not after exc.
            glfwPollEvents()

        glfwTerminate()
    
    def close(self):
        window = self.window
        glfwSetWindowShouldClose(window, 1)
        #https://www.glfw.org/docs/3.3/group__window.html#ga49c449dde2a6f87d996f4daaa09d6708
        #glfwDestroyWindow(window)        


def update(self,dt):
    window = self.window
    inputmanager = self.inputmanager    
    
    #print(dt)

    ii = inputmanager.flush()
    #print(ii,'i')
    #{'M_XY': (9.0, -2.0), 'M_LEFT': (1, 0)}

    if GLFW_KEY_ESCAPE in ii:
        if ii[GLFW_KEY_ESCAPE]==1:
            self.close()
    
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)            
    glDrawArrays(GL_TRIANGLES, 0, 3)


def main():
    
    window = Window(800,600,'justwindow')
    inputmanager = Inputmanager()
    window.bind(inputmanager)
    #controller = Controller()

    #inputmanger.bind(controller)
    
    #controller.bind(camera)
    #controller.set_target

    window.update = update

    # initialize glfw
    #            positions        colors
    triangle = [-0.5, -0.5, 0.0, 1.0, 0.0, 0.0,
                 0.5, -0.5, 0.0, 0.0, 1.0, 0.0,
                 0.0,  0.5, 0.0, 0.0, 0.0, 1.0]

    triangle = numpy.array(triangle, dtype = numpy.float32)

    vertex_shader = """
    #version 330
    in vec3 position;
    in vec3 color;
    out vec3 newColor;
    void main()
    {
        gl_Position = vec4(position, 1.0f);
        newColor = color;
    }
    """

    fragment_shader = """
    #version 330
    in vec3 newColor;
    out vec4 outColor;
    void main()
    {
        outColor = vec4(newColor, 1.0f);
    }
    """
    shader = OpenGL.GL.shaders.compileProgram(OpenGL.GL.shaders.compileShader(vertex_shader, GL_VERTEX_SHADER),
                                             OpenGL.GL.shaders.compileShader(fragment_shader, GL_FRAGMENT_SHADER))


    VAO = glGenVertexArrays(1) # create a VA. if 3, 3of VA got. #errs if no window.
    glBindVertexArray(VAO)
    
    VBO = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, VBO)
    glBufferData(GL_ARRAY_BUFFER, 72, triangle, GL_STATIC_DRAW)

    position = glGetAttribLocation(shader, "position")
    glVertexAttribPointer(position, 3, GL_FLOAT, GL_FALSE, 24, ctypes.c_void_p(0))    
    glEnableVertexAttribArray(position)

    color = glGetAttribLocation(shader, "color")
    glVertexAttribPointer(color, 3, GL_FLOAT, GL_FALSE, 24, ctypes.c_void_p(12))
    #glVertexAttribPointer(attr_index, size, datatype, normalized, stride * fsize, offset)
    glEnableVertexAttribArray(color)

    glUseProgram(shader)


    window.run()


# from smd import SMD
# meshes=[]
# for file in dir():
#     if '.smd' in file:        
#         mesh = SMD.load(file)
#         meshes.append(mesh)

# for mesh in meshes:
#     key = mesh.material.name

# mesh.draw()

import smdloader
fdir = 'Mesh_0009out.smd'
loaded = smdloader.Mesh.load_smd(fdir)
meshes = loaded['meshes']
print('-------------')
mesh = meshes[0]
#dict_keys(['attributes', 'indices', 'material'])
print(mesh['attributes'].keys()) #dict_keys(['position', 'normal', 'uv', 'bones', 'weights'])
print(mesh['material'])
#{'name': 'Tex_0045_0', 'shader': 'default', 'texture': {'diffuse_0': 'Tex_0045_0.png'}}

pos = mesh['attributes']['position']

texfile = mesh['material']['texture']['diffuse_0']
print(texfile)

shader = Shader(vert,frag)
shader = Shader.get('default')
shader.bind()

promat = camera.get_Projection()
viewmat = camera.get_View()
shader.set_mat4('Projection', promat)
shader.set_mat4('View', viewmat)

modelmat = eye4()
shader.set_mat4('Model', modelmat)

texture.bind()
vao.bind()
vao.draw()




# process all input: query GLFW whether relevant keys are pressed/released this frame and react accordingly
# ---------------------------------------------------------------------------------------------------------
class Inputmanager:
    def __init__(self):
        self.events = {}
        self.axis_now={}
        self.axis_now={}
        self.axis_last={}
        self.axis_last={}
    def input(self, key,value,mods=None):        
        self.events[key] = value#,mods
    def input_axis(self,  key,x,y):
        if not key in self.axis_now:
            self.new_axis(key)
        self.axis_now[key]['x'] = x
        self.axis_now[key]['y'] = y
    
    def new_axis(self,key):
        self.axis_now[key] = {'x':0,'y':0}
        self.axis_last[key] = {'x':0,'y':0}        
    
    def flush(self):
        events={}
        for key in self.axis_now:
            x = self.axis_now[key]['x']
            y = self.axis_now[key]['y']
            lastx = self.axis_last[key]['x']
            lasty = self.axis_last[key]['y']
            dx = x-lastx
            dy = y-lasty
            self.axis_last[key]['x'] = x
            self.axis_last[key]['y'] = y
            if dx != 0 and dy != 0:
                events[key] = (dx,dy)

        events.update(self.events)
        self.events = {}        
        return events

GLFW_KEY_ESCAPE


if __name__ == "__main__":
    main()