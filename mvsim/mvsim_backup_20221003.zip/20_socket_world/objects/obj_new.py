
#mesh of dict
#mesh['attrs']['position'] ,uv,normal
#mesh['indices']
#mesh['texture'] = texture_file_name



def obj_save(attrs, indices, texture, fdir):
    lines = []
    header = "# obj created from meshes"
    lines.append(header)
    #o meshname
    #v x y z
    #vt u v
    #vn a b c
    #usemtl mtlname
    #f v/vt/vn v/vt/vn v/vt/vn
    mesh1 = meshes[0]
    objname = mesh1.modelname

    def get_mtlname(mesh):
        texname = mesh.texture.get('diffuse')
        mtlname = splitext(texname)[0]
        if 'diffuse' in mtlname:
            mtlname = mtlname.split('diffuse')[0]
        elif 'albedo' in mtlname:
            mtlname = mtlname.split('albedo')[0]
        return mtlname
    
    def parse_mesh(mesh, lastlen):
        write_method = 123 #123 or 111

        lines = []

        mtllib_ = f"mtllib {mesh.modelname}.mtl"
        lines.append(mtllib_)

        texname = mesh.texture.get('diffuse')
        if not texname:
            texname = mesh.texture.get('albedo')#maybe?
        #---vertex
        o_ = f"o {mesh.name}"
        lines.append(o_)
        #if 'kaidan' in texname:
        #   print(mesh.vert_dict['uv'])

        #for no diffuse now.
        mtlname = get_mtlname(mesh)
        usemtl_ = f"usemtl {mtlname}"
        lines.append(usemtl_)

        s_ = f"s 1"#off, ue4 errs no smoo..
        lines.append(s_)


        if write_method == 123:
            vs = mesh.vert_dict['position']
            vns = mesh.vert_dict['normal']
            vts = mesh.vert_dict['uv']
            for i in range( len(vs)//3 ):
                x = vs[0+i*3]
                y = vs[1+i*3]
                z = vs[2+i*3]
                v_ = f"v {x} {y} {z}"
                lines.append(v_)

                x = vns[0+i*3]
                y = vns[1+i*3]
                z = vns[2+i*3]
                v_ = f"vn {x} {y} {z}"
                lines.append(v_)

                x = vts[0+i*2]
                y = vts[1+i*2]
                v_ = f"vt {x} {y}"
                lines.append(v_)

        elif write_method == 111:
            vs = mesh.vert_dict['position']
            for i in range( len(vs)//3 ):
                x = vs[0+i*3]
                y = vs[1+i*3]
                z = vs[2+i*3]
                v_ = f"v {x} {y} {z}"
                lines.append(v_)

            vts = mesh.vert_dict['uv']
            for i in range( len(vts)//2 ):
                u = vts[0+i*2]
                v = vts[1+i*2]
                vt_ = f"vt {u} {v}"
                lines.append(vt_)

            vns = mesh.vert_dict['normal']
            for i in range( len(vns)//3 ):
                x = vns[0+i*3]
                y = vns[1+i*3]
                z = vns[2+i*3]
                vn_ = f"vn {x} {y} {z}"
                lines.append(vn_)


        #---faces

        idx = mesh.indices
        for i in range( len(idx)//3 ):
            v1 = idx[0+i*3]+1+lastlen
            v2 = idx[1+i*3]+1+lastlen
            v3 = idx[2+i*3]+1+lastlen
            f_ = f"f {v1}/{v1}/{v1} {v2}/{v2}/{v2} {v3}/{v3}/{v3}"
            lines.append(f_)

        lastlen = len(vs)//3
        #print(lastlen)see 1306 406 45, we need to add.
        return lines, lastlen

    lastlen = 0
    for mesh in meshes:
        meshline, verylastlen = parse_mesh(mesh,lastlen)
        lastlen+=verylastlen
        lines.extend(meshline)
    fullline = '\n'.join(lines)
    with open(fdir, 'w', encoding = 'utf-8') as f:
        f.write(fullline)

    mtlline = []
    for mesh in meshes:
        mtlname = get_mtlname(mesh)     
        
        mtlline.append( f"newmtl {mtlname}" )
        mtlline.append( f"Ns 333.0" )
        mtlline.append( f"Ka 1.0 1.0 1.0" )
        mtlline.append( f"Kd 0.8 0.8 0.8" )
        mtlline.append( f"Ks 0.5 0.5 0.5" )
        mtlline.append( f"Ke 0.0 0.0 0.0" )
        mtlline.append( f"Ni 1.45" )
        mtlline.append( f"d 1.0" )
        mtlline.append( f"illum 2" )
        dfile = mesh.texture['diffuse']
        if not dfile:
            dfile = mesh.texture['albedo']
        mtlline.append( f"map_Kd {dfile}" )
        mtlline.append( "" )

    fullline = '\n'.join(mtlline)

    if '.obj' in fdir:
        mtldir = splitext(fdir)[0]+'.mtl'
    else:
        mtldir = fdir+'.mtl'
    with open(mtldir, 'w', encoding = 'utf-8') as f:
        f.write(fullline)