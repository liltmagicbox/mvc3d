import glfw
from glfw.GLFW import *
from OpenGL.GL import *
import OpenGL.GL.shaders
import numpy as np

from mesh_new import Mesh, Shader, Texture
from pymatrix_mini import vec3,eye4,translate, normalize, mperspective,mortho,mlookat
from pymatrix_mini import rotate_x

from camera_new import Camera

from smdloader import smd_load

#smdresult = smd_load('Mesh_0009out.smd')
#meshes = smdresult['meshes']
#mesh = meshes[0]
#print(mesh.keys())
#dict_keys(['attributes', 'indices', 'material'])
#print(mesh['attributes'].keys())
#dict_keys(['position', 'normal', 'uv', 'bones', 'weights'])

#print(mesh['material'])
#{'name': 'Tex_0045_0', 'shader': 'default', 'texture': {'diffuse_0': 'Tex_0045_0.png'}}

import os

from obj_new import obj_save

class Smdman:
    def __init__(self,path):
        self.path = path
        files = os.listdir(path)        
        self.files = [i for i in files if 'smd' in i]
        self.idx = 0
        self.load(0)
        self.meshes=[]
    def loadfile(self,path,file):
        fpath = os.path.join(path,file)
        smdresult = smd_load(fpath)
        meshes = smdresult['meshes']
        smdmesh = meshes[0]
        pos = smdmesh['attributes']['position']
        uvs = smdmesh['attributes']['uv']
        ind = smdmesh['indices']
        texname = smdmesh['material']['name']+'.dds'
        texdir = os.path.join(path,texname)
        #print(fpath,'smdload')
        #print(texdir,'texload')
        tex = Texture.from_img(texdir,flip=False)
        mesh = Mesh(position=pos, uv=uvs, indices = ind, shader='default',texture=tex.name)
        print(tex.name,end='\n')
        return mesh

    def load(self,way):
        self.idx+=way
        if self.idx<0:
            self.idx=0
            print('min idx')
            return
        if self.idx==len(self.files):
            self.idx=len(self.files)-1
            print('max idx')
            return
        file = self.files[self.idx]
        print('----')
        fpath = os.path.join(self.path,file)
        fsize = os.path.getsize(fpath)        
        print(self.idx, 'of',len(self.files)-1, file, 'fsize',fsize,end='/')
        #print( self.files)
        self.mesh = self.loadfile(self.path,file)

    def grab(self):
        texnums = ['0080','0130','0120']
        grabdir = r'C:\Github\3dkatsu\objects\resource\grab'
        grabbers = os.listdir(grabdir)
        texnums = [i.split('_')[1] for i in grabbers]
        print('grabber', texnums)

        meshlist = []
        path = self.path
        for file in self.files:
            fdir = os.path.join(path,file)
            smdresult = smd_load(fdir)
            meshes = smdresult['meshes']
            smdmesh = meshes[0]
            pos = smdmesh['attributes']['position']
            uvs = smdmesh['attributes']['uv']
            normals = smdmesh['attributes']['normal']
            ind = smdmesh['indices']
            texname = smdmesh['material']['name']+'.dds'
            
            texnum = smdmesh['material']['name'].split('_')[1]
            if texnum in texnums:
                print(file, texname)                
                texpath = os.path.join(path, texname )
                tex = Texture.from_img(texpath,False)
                m = Mesh(position=pos,indices=ind, uv = uvs,normal=normals, texture=tex.name, name=file)                
                meshlist.append(m)
        self.meshes = meshlist
        #--------phase2, merge.
        def get_dist(mesh):
            pos = mesh.attrs['position']
            return sum(pos)

        def merge(meshes):
            if len(meshes)==0:
                return
            pos_merged = []
            uv_merged = []
            normal_merged = []
            indices_merged = []
            offset=0
            mesh_dist_dict = {}
            for mesh in meshes:
                dist = get_dist(mesh)                
                if dist in mesh_dist_dict:
                    oldmesh = mesh_dist_dict[dist]
                    print('skip add mesh.', mesh.name, oldmesh.name)
                    continue
                else:
                    print('new one',mesh.texture)
                    mesh_dist_dict[dist] = mesh
                pos_merged.extend(mesh.attrs['position'])
                uv_merged.extend(mesh.attrs['uv'])
                normal_merged.extend(mesh.attrs['normal'])
                off_ind = [i+offset for i in mesh.indices]
                indices_merged.extend(off_ind)
                offset += len(mesh.attrs['position'])//3                

                tex_name = mesh.texture
            return Mesh(position=pos_merged,indices=indices_merged, uv = uv_merged,normal=normal_merged, texture=tex_name)
        
        #texnums
        botmesh = []
        for mesh in self.meshes:
            if '0080' in mesh.texture:
                botmesh.append(mesh)
        merged_mesh = merge(botmesh)        
        self.mesh = merged_mesh
        self.meshes = []
        
        attrs = {
        'position': merged_mesh.attrs['position'],
        'uv': merged_mesh.attrs['uv'],
        'normal': merged_mesh.attrs['normal'],        
        }
        indices = merged_mesh.indices
        texture = merged_mesh.texture
        print(texture,'objsaving texture name')
        obj_save(attrs,indices,texture,'merged.obj')

    def draw(self,M,V,P):
        if self.meshes==[]:
            self.mesh.draw(M,V,P)
        else:
            for mesh in self.meshes:
                mesh.draw(M,V,P)


    def focus(self):
        self.focused = self.mesh
        pos = self.focused.attrs['position']
        self.focused = pos
        print(self.mesh.name,'focused')
    def compare(self):
        try:
            mesh = self.mesh
            npos = mesh.attrs['position']
            dist = []
            for idx in range(len(self.focused)):
                dis = self.focused[idx] - npos[idx]
                dist.append(dis)
            print( sum(dist)/len(dist) , f"distance of {mesh.name}")
        except:
            print('compare error')



def main():
    # Initialize the library
    if not glfw.init():
        return
    # Create a windowed mode window and its OpenGL context
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4)
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3)
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE)
    glfwWindowHint(GLFW_DOUBLEBUFFER, GLFW_TRUE)
    window = glfw.create_window(640, 480, "Hello World", None, None)
    if not window:
        glfw.terminate()
        return

    # Make the window's context current
    glfw.make_context_current(window)
    glEnable(GL_DEPTH_TEST)
    glClearColor(0.2, 0.3, 0.2, 1.0)
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED)#GLFW_CURSOR_NORMAL    
    if glfwRawMouseMotionSupported():
        glfwSetInputMode(window, GLFW_RAW_MOUSE_MOTION, GLFW_TRUE)

    class M_DXDY:
        lastx,lasty = 0,0
    def mouse_callback(window, xpos: float, ypos: float) -> None:
        dx = xpos-M_DXDY.lastx
        #dy = ypos-M_DXDY.lasty
        dy = M_DXDY.lasty-ypos
        M_DXDY.lastx = xpos
        M_DXDY.lasty = ypos
        #print(dx,dy)
        #cam.mouse_moveDXDY(dx,dy)
    glfwSetCursorPosCallback(window, mouse_callback)

    def key_callback(window, key,scancode,action,mods):
        #https://www.glfw.org/docs/3.3/group__keys.html
        if key == GLFW_KEY_PAGE_UP and action==1:
            smdman.load(1)
        elif key == GLFW_KEY_PAGE_DOWN and action==1:
            smdman.load(-1)

        elif key == GLFW_KEY_F and action==1:
            smdman.focus()
        elif key == GLFW_KEY_C and action==1:
            smdman.compare()

        elif key == GLFW_KEY_G and action==1:
            smdman.grab()

    glfwSetKeyCallback(window,key_callback)
    #-----------------
    triangle = [-0.5, -0.5, 0.0, 1.0, 0.0, 0.0,
                 0.5, -0.5, 0.0, 0.0, 1.0, 0.0,
                 0.0,  0.5, 0.0, 0.0, 0.0, 1.0]

    triangle = np.array(triangle, dtype = np.float32)

    vertex_shader = """
    #version 330
    in vec3 position;
    in vec3 color;
    out vec3 newColor;
    void main()
    {
        gl_Position = vec4(position, 1.0f);
        newColor = color;
    }
    """

    fragment_shader = """
    #version 330
    in vec3 newColor;
    out vec4 outColor;
    void main()
    {
        outColor = vec4(newColor, 1.0f);
    }
    """
    shader = OpenGL.GL.shaders.compileProgram(OpenGL.GL.shaders.compileShader(vertex_shader, GL_VERTEX_SHADER),
                                             OpenGL.GL.shaders.compileShader(fragment_shader, GL_FRAGMENT_SHADER))


    VAO = glGenVertexArrays(1) # create a VA. if 3, 3of VA got. #errs if no window.
    glBindVertexArray(VAO)
    
    VBO = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, VBO)
    glBufferData(GL_ARRAY_BUFFER, 72, triangle, GL_STATIC_DRAW)

    position = glGetAttribLocation(shader, "position")
    glVertexAttribPointer(position, 3, GL_FLOAT, GL_FALSE, 24, ctypes.c_void_p(0))    
    glEnableVertexAttribArray(position)

    color = glGetAttribLocation(shader, "color")
    glVertexAttribPointer(color, 3, GL_FLOAT, GL_FALSE, 24, ctypes.c_void_p(12))
    #glVertexAttribPointer(attr_index, size, datatype, normalized, stride * fsize, offset)
    glEnableVertexAttribArray(color)

    glUseProgram(shader)


    vertn = """
    #version 410 core

    layout (location = 0) in vec3 position;
    layout (location = 1) in vec2 uv;
    out vec2 uvcord;

    uniform mat4 Model;
    uniform mat4 View;
    uniform mat4 Projection;

    void main() 
    {
        gl_Position = Projection * View * Model * vec4(position, 1);
        //gl_Position = vec4(position, 1);        
        //gl_Position = vec4(position.x-0.51,position.y,position.z,1);
        uvcord = uv;
    }
    """

    fragn = """
    #version 410 core

    in vec2 uvcord;
    out vec4 outcolor;

    uniform sampler2D tex0;

    void main()
    {
        outcolor = texture2D(tex0, uvcord);
    }
    """

    sha = Shader(vertn, fragn,'default')
    #tri = [0,0,0, 1,0,0, 1,1,0, 0,1,0]
    #uvs = [0,0, 1,0, 1,1, 0,1]
    #ind = [0,1,2, 0,2,3]
    #ind = [0,1,2,0,2,3]

    tris = [0,0,0, 1,0,0, 0,1,0, 1,1,0]
    colors = [1,0,0, 0,1,0, 0,0,1]
    uvs = [0,0, 1,0, 0,1, 1,1]
    ind = [0,1,2, 1,2,3]
    #tex = Texture.from_img('boxtexture.png')
    texname = 'texture2.jpg'
    tex = Texture.from_img(texname)
    texname = 'rrr.png'
    texname = 'Tex_0045_0.dds'
    tex = Texture.from_img(texname)
    #mesh = Mesh(position=tris, uv=uvs, color=colors, indices = ind, shader='default',texture=texname)
    
    #mesh = Mesh(position=tris, uv=uvs, indices = ind, shader='default',texture=texname)
    #print(mesh.attrs)
    #print(mesh.indices)

    smdresult = smd_load('Mesh_0009out.smd')
    meshes = smdresult['meshes']
    smdmesh = meshes[0]
    pos = smdmesh['attributes']['position']
    uvs = smdmesh['attributes']['uv']
    ind = smdmesh['indices']
    texname = smdmesh['material']['name']+'.dds'
    tex = Texture.from_img(texname,True)

    mesh = Mesh(position=pos, uv=uvs, indices = ind, shader='default',texture=texname)


    smdman = Smdman(path='resource')


    #glBindVertexArray(VAO)
    #mesh.vao.bind()
    cam = Camera(640/480)
    cam.pos = vec3(0,0,2)
    #------------------
    # Loop until the user closes the window

    M = [1,0,0,0, 0,1,0,0, 0,0,1,0, -0.01,0,0,1]
    deg = 0
    while not glfw.window_should_close(window):
        # Render here, e.g. using pyOpenGL
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)

        if glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS:
            glfw.set_window_should_close(window,1)

        elif glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS:
            cam.pos = cam.pos+vec3(0,0,0.1)
        elif glfwGetKey(window, GLFW_KEY_W) == GLFW_PRESS:
            cam.pos = cam.pos+vec3(0,0,-0.1)
        elif glfwGetKey(window, GLFW_KEY_D) == GLFW_PRESS:
            cam.pos = cam.pos+vec3(0.1,0,0)
        elif glfwGetKey(window, GLFW_KEY_A) == GLFW_PRESS:
            cam.pos = cam.pos+vec3(-0.1,0,0)

        elif glfwGetKey(window, GLFW_KEY_E) == GLFW_PRESS:
            deg+=10
        elif glfwGetKey(window, GLFW_KEY_Q) == GLFW_PRESS:
            deg-=10
        M = rotate_x(M,deg)


        #cam.mouse_moveDXDY(dx,dy)
        
        #glBindVertexArray(VAO)
        #glDrawArrays(GL_TRIANGLES, 0, 3)
        #mesh.vao.bind()
        #mesh.vao.draw()
        V = cam.get_View()
        P = cam.get_Projection()        
        
        #mesh = smdman.mesh
        #mesh.draw(M,V,P)
        smdman.draw(M,V,P)
        #mesh.draw(M,M,M)

        #glUseProgram(shader)
        #sha.bind()
        #mesh.vao.bind()
        #mesh.vao.draw(GL_TRIANGLES)

        #P = eye4()
        #V = eye4()
        #M = eye4()
        #mesh.draw(M,V,P)

        # Swap front and back buffers
        glfw.swap_buffers(window)

        # Poll for and process events
        glfw.poll_events()

    glfw.terminate()

if __name__ == "__main__":
    main()

#0.3cpu, 27.5MB, gpu10% of 750ti.