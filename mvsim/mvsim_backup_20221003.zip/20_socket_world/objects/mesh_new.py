from VAO_new import VAO
from shader_new import Shader
from texture_new import Texture

class SMD:
	@classmethod
	def from_dict(cls,attrdict, indices=None):
		"""attrdict (pos,normal,uv,weights=None)"""
		def to_vertex(parent, pos,normal,uv, weights):
			links = len(weights)//2
			weightstr = str(links)
			for i in range(links):
				b = weights[i]
				w = weights[i+1]
				weightstr+= f" {b} {w}"
			line = f" {parent} {posx} {posy} {posz} {norx} {nory} {norz} {uvx} {uvy} {weightstr}"
			return line
		

		pos = attrdict['pos']
		normal = attrdict['normal']
		uv = attrdict['uv']		
		weights = attrdict.get('weights')
		if indices==None:
			indices = [i for i in range(len(pos)//3)]

		verts = []
		for i in indices:
			#https://developer.valvesoftware.com/wiki/Studiomdl_Data#Triangles
			sparent = 0
			spos = pos[i:i+3]
			snormal = normal[i:i+3]
			suv = uv[i:i+2]
			if weights:
				sweights = weights[i:i+8]
			else:
				sweights = [0,1]
			vert_line = to_vertex(sparent, spos,snormal,suv,sweights)
			verts.append(vert_line)
		return verts
	def __init__(self, nodes, skeleton, triangles):
		lines = []
		line_ver = "version 1"
	#line = f' {N} "{name}" {parent}'
	def line_to_nodes(self,nodes):
		#node: 0 "root"  -1
		lines = []
		header = 'nodes'
		ender = 'end'
		lines.append(header)
		for node in nodes:
			lines.append(node)
		lines.append(ender)
		return lines
	def line_to_skeleton(self,skeletons):
		#skeleton: 0 0.000000 0.000000 0.000000 0.000000 -0.000000 0.000000
		lines = []
		header = 'skeleton'
		ender = 'end'
		lines.append(header)
		timer = 0
		for skeleton in skeletons:
			timestr = 
			lines.append(timestr)
			lines.append(node)
		lines.append(ender)
		return lines
	def line_to_triangles(self,verts, matname):
		#vert: 0 -0.348687 0.003982 0.113621 -0.004933 0.003593 0.006796 0.160109 0.605452 1 0 1.000000
		lines = []
		header = 'triangles'
		ender = 'end'
		lines.append(header)
		for idx, vert in enumerate(verts):
			if idx//3==0:				
				lines.append(matname)
			lines.append(vert)
		lines.append(ender)
		return lines
	def merge_triangles(self, tri1,tri2):




class Mesh:
	def __init__(self, pos_or_attrdict, indices=None, name=None, texture={'color':'default'}, shader='default'):		
		if isinstance(pos_or_attrdict, dict):
			attrs=pos_or_attrdict
		else:#assume list or nparray
			pos = pos_or_attrdict
			attrs = {'pos':pos}

		self.attrs = attrs
		if indices == None:
			indices = [i for i in range(len(pos)//3)]
		self.vao = VAO(attrs,indices)
		self.indices = indices

		if name == None:
			name = texture['color']
		self.name = name
		self.texture = texture
		self.shader = shader

	def draw(self, M,V,P):
		shader = Shader.get(self.shader)
		shader.bind()
		shader.set_mat4('Projection',P)
		shader.set_mat4('View',V)
		shader.set_mat4('Model',M)

		self.texture_bind(shader)
		self.vao.bind()
		self.vao.draw()

	def to_smd(self):
		attrdict = self.attrs
		indices = self.indices
		smd = SMD.from_dict(attrdict,indices)
		smd.save('smdsaved.smd')

	def update(self):
		self.vao.update(self.attrs)
	
	def texture_bind(self, shader:Shader):
		texture = self.texture
		texchan = 0#it just binds temporary texture channel. fine.
		for channel,texname in texture.items():
			tex = Texture.get(texname)
			loc = shader.get_loc(channel)
			shader.set_int(loc, texchan)
			#shader.set_texture(channel, texchan)
			tex.bind(texchan)
			texchan+=1

#------------usages

# mesh = Mesh(pos=pos,indices=indices)
# mesh = Mesh(pos=pos,indices=indices, name = 'peng')
# mesh = Mesh(pos=pos,indices=indices, texture = 'peng.png')
# mesh = Mesh(pos=pos,indices=indices, texture = 'peng.png', shader='redshader')
# mesh = Mesh(pos=pos,indices=indices, texture = {'color':'peng.png','metallic':'metal.png'}, shader='bsdf')

# mesh.bind()
# mesh.draw()


# shader.bind()
# shader.set_mat4('Projection',promat)
# shader.set_mat4('View',viewmat)
# shader.set_mat4('Model',modelmat)
# texture.bind()
# mesh.vao.bind()
# mesh.vao.draw()

# shader.bind()
# shader.set_mat4('Projection',promat)
# shader.set_mat4('View',viewmat)
# shader.set_mat4('Model',modelmat)
# loc = shader.get_loc('color')
# shader.set_int(loc,0)
# texture.bind(0)
# mesh.vao.bind()
# mesh.vao.draw()

# shader.bind()
# shader.set_mat4('Projection',promat)
# shader.set_mat4('View',viewmat)
# shader.set_mat4('Model',modelmat)
# #shader.set_texture('color', 0)# if 0 shader, we can skip this..
# #texture.bind(0) #0 default.
# texture.bind()
# mesh.vao.bind()
# mesh.vao.draw()


# mesh.attrs['pos'] = []
# mesh.pos = []
# mesh.update()