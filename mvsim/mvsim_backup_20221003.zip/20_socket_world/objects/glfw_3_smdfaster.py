#https://github.com/totex/PyOpenGL_tutorials/blob/master/main.py

#import glfw

from glfw import _GLFWwindow as GLFWwindow
from glfw.GLFW import *
from OpenGL.GL import *
import OpenGL.GL.shaders
##from OpenGL.GL import shaders
import numpy


SCR_WIDTH = 800
SCR_HEIGHT = 600

def main():
    if not glfwInit():
        return
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 4)
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3)
    glfwWindowHint(GLFW_OPENGL_PROFILE, GLFW_OPENGL_CORE_PROFILE)
    glfwWindowHint(GLFW_DOUBLEBUFFER, GLFW_TRUE)#for vsync. we do d.buffer atleast!!
    #window = glfw.create_window(800, 600, "My OpenGL window", None, None)        

    window = glfwCreateWindow(SCR_WIDTH, SCR_HEIGHT, "My OpenGL window", None, None)
    if not window:
        glfwTerminate()
        return
    glfwMakeContextCurrent(window)
    glEnable(GL_DEPTH_TEST)
    glClearColor(0.2, 0.3, 0.2, 1.0)
    
    # glfw: whenever the window size changed (by OS or user resize) this callback function executes
    def framebuffer_size_callback(window: GLFWwindow, width: int, height: int) -> None:
        # make sure the viewport matches the new window dimensions note that width and 
        # height will be significantly larger than specified on retina displays.
        glViewport(0, 0, width, height)
    glfwSetFramebufferSizeCallback(window, framebuffer_size_callback)
    
    #https://www.glfw.org/docs/3.3/group__input.html#gaa92336e173da9c8834558b54ee80563b
    glfwSetInputMode(window, GLFW_CURSOR, GLFW_CURSOR_DISABLED)#GLFW_CURSOR_NORMAL
    #glfwSetKeyCallback(window, key_callback)
    #glfwSetMouseButtonCallback(window, mouse_button_callback)
    #glfwSetCursorPosCallback(window, mouse_callback)
    #glfwSetScrollCallback(window, scroll_callback)

    #glfwSetWindowShouldClose(window, 1)
    
    


    # initialize glfw
    #            positions        colors
    triangle = [-0.5, -0.5, 0.0, 1.0, 0.0, 0.0,
                 0.5, -0.5, 0.0, 0.0, 1.0, 0.0,
                 0.0,  0.5, 0.0, 0.0, 0.0, 1.0]

    triangle = numpy.array(triangle, dtype = numpy.float32)

    vertex_shader = """
    #version 330
    in vec3 position;
    in vec3 color;
    out vec3 newColor;
    void main()
    {
        gl_Position = vec4(position, 1.0f);
        newColor = color;
    }
    """

    fragment_shader = """
    #version 330
    in vec3 newColor;
    out vec4 outColor;
    void main()
    {
        outColor = vec4(newColor, 1.0f);
    }
    """
    shader = OpenGL.GL.shaders.compileProgram(OpenGL.GL.shaders.compileShader(vertex_shader, GL_VERTEX_SHADER),
                                             OpenGL.GL.shaders.compileShader(fragment_shader, GL_FRAGMENT_SHADER))


    VAO = glGenVertexArrays(1) # create a VA. if 3, 3of VA got. #errs if no window.
    glBindVertexArray(VAO)
    
    VBO = glGenBuffers(1)
    glBindBuffer(GL_ARRAY_BUFFER, VBO)
    glBufferData(GL_ARRAY_BUFFER, 72, triangle, GL_STATIC_DRAW)

    position = glGetAttribLocation(shader, "position")
    glVertexAttribPointer(position, 3, GL_FLOAT, GL_FALSE, 24, ctypes.c_void_p(0))    
    glEnableVertexAttribArray(position)

    color = glGetAttribLocation(shader, "color")
    glVertexAttribPointer(color, 3, GL_FLOAT, GL_FALSE, 24, ctypes.c_void_p(12))
    #glVertexAttribPointer(attr_index, size, datatype, normalized, stride * fsize, offset)
    glEnableVertexAttribArray(color)

    glUseProgram(shader)


    
    timebefore=0
    while not glfwWindowShouldClose(window):
        timenow = glfwGetTime()
        dt = timenow-timebefore
        timebefore = timenow
        
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT)            
        glDrawArrays(GL_TRIANGLES, 0, 3)

        #dbuffer True, use swapbuffer. interval0 if fullspeed test.
        #dbuffer False, use glFlush, the old way maybe.fine.
        #glfwSwapInterval(1)# 10 160ms tooslow, 1 16ms, 0 fastest
        glfwSwapBuffers(window)#requires dbuffer True.
        #glFlush()#when not using vsync #-- we found, flush returns anytime, not after exc.
        glfwPollEvents()

    glfwTerminate()



if __name__ == "__main__":
    main()