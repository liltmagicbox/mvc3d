import numpy as np
from OpenGL.GL import *

class VAO:
    def __init__(self, attrs,indices):
        attrlist=[]
        for data_array in attrs.values():
            attrlist.append(data_array)
        vertices = np.concatenate(attrlist).astype('float32')
        indices = np.array(indices).astype('uint32')
        
        #--------vao
        VAO = glGenVertexArrays(1) # create a VA. if 3, 3of VA got. #errs if no window.
        VBO = glGenBuffers(1) #it's buffer, for data of vao.fine.
        EBO = glGenBuffers(1) #indexed, so EBO also. yeah.
        glBindVertexArray(VAO) #gpu bind VAO
        glBindBuffer(GL_ARRAY_BUFFER, VBO) #gpu bind VBO in VAO
        glBufferData(GL_ARRAY_BUFFER, vertices.nbytes, vertices, GL_STATIC_DRAW)
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, EBO)
        glBufferData(GL_ELEMENT_ARRAY_BUFFER, indices.nbytes, indices, GL_STATIC_DRAW)

        #--------attrs
        #glVertexAttribPointer(attr_index, size, datatype, normalized, stride, offset)
        points = len(attrs['position'])//3
        fsize = np.float32(0.0).nbytes #to ensure namespace-safe.        
        offset = ctypes.c_void_p(0)
        loc = 0
        for data_array in attrs.values():
            data_len = len(data_array)
            size = data_len//points#size 2,3,4            
            #loc = glGetAttribLocation(shader.ID, attrname)            
            glVertexAttribPointer(loc, size, GL_FLOAT, GL_FALSE, 0, offset)
            glEnableVertexAttribArray(loc)
            offset = ctypes.c_void_p(data_len*fsize)
            loc+=1

        self.VAO = VAO
        self.VBO = VBO
        self.EBO = EBO
        self.points = len(indices)
    def update(self,attrs):
        VAO = self.VAO
        VBO = self.VBO
        attrlist=[]
        for data_array in attrs.values():
            attrlist.append(data_array)
        vertices = np.concatenate(attrlist).astype('float32')        
        glBindVertexArray(VAO) #gpu bind VAO
        glBindBuffer(GL_ARRAY_BUFFER, VBO) #gpu bind VBO in VAO
        glBufferData(GL_ARRAY_BUFFER, vertices.nbytes, vertices, GL_STATIC_DRAW)

    def bind(self):
        glBindVertexArray(self.VAO)    
    def unbind(self):
        glBindVertexArray(0)
    def draw(self, MODE = GL_TRIANGLES):
        glDrawElements(MODE, self.points, GL_UNSIGNED_INT, None)

#vao = VAO(pos,indices, uv,normal,weights)