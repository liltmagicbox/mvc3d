import glfw
a = dir(glfw)
for i in a:
    if 'ime' in i:
        print(i)
#from glfw.GLFW import glfwGetTime
#print(help(glfw.get_time))
#print(help(glfwGetTime))
#2 same.

class TimePlayer:
    """basic player, play/pause. for anim, vid without aud.   /aud has own player."""
    def __init__(self):
        self.is_playing = False
        self.time = 0
        self.need = False
        
        self.times=[]
    def play(self):
        self.is_playing = True        
    def pause(self):
        self.is_playing = False
    def play_pause(self):
        if self.is_playing:
            self.pause()
            print('pause')
        else:
            self.play()
            print('play')
    def tick(self, time, dt):
        if self.is_playing:
            self.time+=dt
            #print(self.time)

import time

printer = False
ts = 0

T = TimePlayer()
def main():
    global printer,ts
    # Initialize the library
    if not glfw.init():
        return
    # Create a windowed mode window and its OpenGL context
    window = glfw.create_window(640, 480, "Hello World", None, None)
    if not window:
        glfw.terminate()
        return

    # Make the window's context current
    glfw.make_context_current(window)
    # Loop until the user closes the window
    

    #glfwSetKeyCallback(window, key_callback);
    glfw.set_key_callback(window, key_callback)
    #glfw.set_time(5550)    
    gt = glfw.get_time()
    #tt = glfwGetTime()
    timewas = 0
    while not glfw.window_should_close(window):
        # Render here, e.g. using pyOpenGL
        #t = glfw.get_timer_value()#20540838386 2054 is seconds.
        t = glfw.get_time()
        dt = t-timewas
        timewas = t
        if printer:
            print('============',t)
            ttt = time.time()
            dts = ttt-ts
            ts = ttt
            print('-init player',dts)
            print(T.time)
            printer = False
        re = T.tick(t, dt)

        #if int(t%2)==0:
        #    T.play()
        #else:
        #    T.pause()            

        # Swap front and back buffers
        glfw.swap_buffers(window)

        # Poll for and process events
        glfw.poll_events()
    #5.0900804 4.99566 100ms different! 70ms from start however.
    #0.0998335
    #11.307341099999999 11.3184877 quite accurate. 9.9ms became 11ms.
    #anyway 20ms difference.
    glfw.terminate()

def key_callback(window, key, scancode, action, mods):
    global printer
    #if (key == GLFW_KEY_E and action == GLFW_PRESS):
    if (key == glfw.KEY_SPACE and action == glfw.PRESS):
        T.play_pause()
        if T.is_playing:
            printer = True
        else:
            printer = True
            print('-------------NEd')


if __name__ == "__main__":
    main()

#0.3cpu, 27.5MB, gpu10% of 750ti.