class Inputmanager:
    def __init__(self):
        self.events = {}
        
        self.axis_now={}
        self.axis_before={}
    def input(self, key,value,mods=None):
        modsdict={
        0:'',
        1:'+SHIFT',
        2:'+CTRL',
        4:'+ALT',
        3:'+SHIFT+CTRL',
        5:'+SHIFT+ALT',
        6:'+CTRL+ALT',
        7:'+SHIFT+CTRL+ALT',
        }
        #print(key,value,mods)
        #mods & MOD_CTRL and mods & MOD_ALT
        #'CTRL' in key and 'ALT' in key #better.    
        #key = pyglet.window.key.symbol_string(symbol) 
        #key += modsdict[mods]
        #self.events[key] = value#overwrite!
        self.events[key] = value,mods

    def input_axis(self,  key,x,y,z=None):
        if not key in self.axis_now:
            #self.new_axis(key)
            self.axis_now[key] = {'x':0,'y':0}
            self.axis_before[key] = {'x':0,'y':0}
        self.axis_now[key]['x']=x
        self.axis_now[key]['y']=y
        if not z==None:
            self.axis_now[key]['z']=z

    def new_axis(self,key, z=None):
        if z==None:
            self.axis_now[key] = {'x':0,'y':0}
            self.axis_before[key] = {'x':0,'y':0}
        else:
            self.axis_now[key] = {'x':0,'y':0,'z':0}
            self.axis_before[key] = {'x':0,'y':0,'z':0}

    def flush(self):
        axis_now = self.axis_now
        axis_before = self.axis_before
        for key in axis_now:
            now = axis_now[key]
            before = axis_before[key]
            dx = now['x']-before['x']
            dy = now['y']-before['y']
            if 'z' in now:
                dz = now['z']-before['z']
            print(key,dx,dy,'dd')
            axis_before[key] = axis_now[key]
        #print(axisvalue,'axis')
        #print(self.events)


        #.update(self.events)#merge a to b
        events = self.events
        self.axisvalue = {}
        self.events = {}
        return events