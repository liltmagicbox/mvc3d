#fast model smd loader. tri first. easy to see..


with open(fdir, 'w', encoding = 'utf-8') as f:
    f.write(fullline)

#when triangle mode

if line==END:
    1
vertex = parse_vertex(line)
vertex.pos
vertex.uv
vertex.normal


