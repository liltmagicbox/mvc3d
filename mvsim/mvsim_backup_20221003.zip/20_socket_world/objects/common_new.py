def get_namekey(namedict, name):
    if name in namedict:
        baridx = name.rfind('_')
        if baridx == -1:
            name = name+'_0'
            name = get_namekey(namedict,name)
        else:
            front = name[:baridx]
            back = name[baridx+1:]
            if back.isdecimal():#digit 3^3, numeric 3.3E06
                i = int(back)+1
                name = f"{front}_{i}"
                name = get_namekey(namedict,name)
            else:
                name = name+'_0'
                name = get_namekey(namedict,name)
    return name

class GetSet:
    #----------getset ver0.2
    last = -1    
    namedict = {}
    @classmethod
    def get(cls, name):
        return cls.namedict.get(name)
    @classmethod
    def set(cls, name: str, item) -> str:
        name = get_namekey(cls.namedict,name)
        cls.namedict[name]=item
        return name
    #----------getset ver0.2