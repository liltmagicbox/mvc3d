import glfw
a = dir(glfw)
for i in a:
    if 'ime' in i:
        print(i)
#from glfw.GLFW import glfwGetTime
#print(help(glfw.get_time))
#print(help(glfwGetTime))
#2 same.


def main():
    # Initialize the library
    if not glfw.init():
        return
    # Create a windowed mode window and its OpenGL context
    window = glfw.create_window(640, 480, "Hello World", None, None)
    if not window:
        glfw.terminate()
        return

    # Make the window's context current
    glfw.make_context_current(window)
    # Loop until the user closes the window
    #glfw.set_time(5550)
    gt = glfw.get_time()
    #tt = glfwGetTime()
    pre_time = 0
    dts = 0
    gdt = 0
    first = True
    while not glfw.window_should_close(window):
        # Render here, e.g. using pyOpenGL
        #t = glfw.get_timer_value()#20540838386 2054 is seconds.
        t = glfw.get_time()
        if t>2:
            if first:
                first=False
                pre_time = t
                dts = 0
                gdt = t
            dt = t-pre_time
            dts+=dt
        pre_time = t

        # Swap front and back buffers
        glfw.swap_buffers(window)

        # Poll for and process events
        glfw.poll_events()
    gdt = glfw.get_time()-gdt
    print(gdt,dts)#5.0900804 4.99566 100ms different! 70ms from start however.
    #0.0998335
    #11.307341099999999 11.3184877 quite accurate. 9.9ms became 11ms.
    #anyway 20ms difference.
    glfw.terminate()

if __name__ == "__main__":
    main()

#0.3cpu, 27.5MB, gpu10% of 750ti.