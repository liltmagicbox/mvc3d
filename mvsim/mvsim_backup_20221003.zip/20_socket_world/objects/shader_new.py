from OpenGL.GL import *
from OpenGL.GL import shaders

from common_new import get_namekey

class Shader:
    #----------getset ver0.2
    last = -1    
    namedict = {}
    @classmethod
    def get(cls, name):
        return cls.namedict.get(name)
    @classmethod
    def set(cls, name: str, item) -> str:
        name = get_namekey(cls.namedict,name)
        cls.namedict[name]=item
        return name
    #----------getset ver0.2

    def __init__(self, vertstr, fragstr, name='shader'):
        assert bool(glCreateShader)#sometimes compile error occurs, before window() 
        vshader = shaders.compileShader( vertstr, GL_VERTEX_SHADER)
        fshader = shaders.compileShader( fragstr, GL_FRAGMENT_SHADER)
        program = shaders.compileProgram( vshader,fshader)
        glDeleteShader(vshader)
        glDeleteShader(fshader)
        self.ID= program
        self.loc={}        
        name = self.__class__.set(name,self)
        self.name = name

    def bind(self):
        cls = self.__class__
        if cls.last != self.ID:
            glUseProgram(self.ID)
            cls.last = self.ID
    def unbind(self):
        glUseProgram(0)
        self.__class__.last = -1

    def get_loc(self, uniform_name):
        loc = self.loc.get(uniform_name)
        if not loc:
            program = self.ID
            loc = glGetUniformLocation(program, uniform_name)
            self.loc[uniform_name] = loc
        return loc

    def set_int(self, uniform_name, value):
        loc = self.get_loc(uniform_name)
        glUniform1i(loc,value)
    def set_float(self, uniform_name, value):
        loc = self.get_loc(uniform_name)
        glUniform1f(loc,value)
    def set_vec3(self, uniform_name, x,y,z):
        loc = self.get_loc(uniform_name)
        glUniform3f(loc, x,y,z)     
    def set_mat4(self, uniform_name, mat):
        """we need bind the shader first!"""
        loc = self.get_loc(uniform_name)
        glUniformMatrix4fv(loc,1,False, mat)# True for row major..[1,2,3,4, ,]
        #location count transpose data(nparr)
