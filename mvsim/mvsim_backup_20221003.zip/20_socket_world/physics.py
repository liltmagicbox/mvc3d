

#ActorPhysics
#PosActor
#ActPos
#class Sprite(IActor, Pos, Gravity):
#class MeshActor(IActor, Pos, Rot, Gravity):
actor_requirements = """
update pos+=speed*dt kinds .. may be replaced by AXIS. incapsulate it!

"""

from vec import Vec3

#center of mass!
#and of rotation,too!
class Physics:
    __slots__ = ['gravity_scale', 'force','mass','acc','speed','pos' ,'racc','rspeed','rpos']
    def __init__(self):
        self.gravity_scale = 0
        self.force = Vec3(0,0,0)
        self.mass = 1
        self.acc = Vec3(0,0,0)
        self.speed = Vec3(0,0,0)
        self.pos = Vec3(0,0,0)

        self.racc = Vec3(0,0,0)
        self.rspeed = Vec3(0,0,0)
        self.rpos = Vec3(0,0,0)
    
    def _update_physics(self,dt):
        #f = m*a, a=f/m.
        acc_by_force = self.force/self.mass
        self.acc += acc_by_force *dt
        self.speed += (self.acc + (0,0, -9.80665*self.gravity_scale) )* dt
        self.pos += self.speed * dt

        #self.racc += acc_by_force *dt#racc not yet.
        self.rspeed += self.racc * dt
        self.rpos += self.rspeed * dt
    @property
    def rot(self):
        return self.rpos
    @rot.setter
    def rot(self,value):
        self.rpos = value
    #===
    @property
    def front(self):
        return self.rpos
    @front.setter
    def front(self,value):
        self.rpos = value
    

def _phytest():
    a = Physics()
    #a.speed=(1,0,0)
    a.gravity_scale =1
    a.speed.set(1,0,0)
    for i in range(300):
        a._update_physics(0.01)
    #3s freefall, speed 29.4m/s pos 44.2m.
    print(a.speed,a.pos)

if __name__ == '__main__':
    _phytest()
    #main()










class Position:
    __slots__ = ['force','mass','acc','speed','pos']
    def __init__(self):
        self.force = Vec3(0,0,0)
        self.mass = 1
        self.acc = Vec3(0,0,0)
        self.speed = Vec3(0,0,0)
        self.pos = Vec3(0,0,0)
    def _update(self,dt):
        #f = m*a, a=f/m.        
        acc_by_force = self.force/self.mass
        self.acc += acc_by_force *dt
        self.speed += self.acc * dt
        self.pos += self.speed * dt

class Rotation:
    __slots__ = ['acc','speed','pos']
    def __init__(self):
        self.racc = Vec3(0,0,0)
        self.rspeed = Vec3(0,0,0)
        self.rpos = Vec3(0,0,0)
    def _update(self,dt):
        self.racc += acc_by_force *dt
        self.rspeed += self.racc * dt
        self.rpos += self.rspeed * dt
    @property
    def rot(self):
        return self.rpos
    @rot.setter
    def rot(self,value):
        self.rpos = value
