
from fastestobjread import OBJ

fdir = 'yup/fbox.obj'

def loadobj_return_vlist_texture(objname):
    obj =OBJ(objname)
    
    #pic = pyglet.image.load(obj.texture)
    #texture = pic.get_texture()
    #print(obj.multices)

    faces = obj.idxs
    #print(faces,len(faces))
    #[0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17,
    #0, 18, 1, 3, 19, 4, 6, 20, 7, 9, 21, 10, 12, 22, 13, 15, 23, 16] 36
    
    vertex_count = len(obj.multices)
    vertex_coordinate = []
    vertex_uv = []
    #print(vertex_count)#24
    #print(obj.multices)

    norm = []
    for multex in obj.multices:
        vert = multex[0]
        uv = multex[1]
        norm.extend(multex[2])
        vertex_coordinate.extend(vert)
        vertex_uv.extend(uv)
    return vertex_coordinate,vertex_uv,norm,faces

# vertex_coordinate,vertex_uv,faces = loadobj_return_vlist_texture(fdir)

# data = {
#     'position':vertex_coordinate,
#     'texture':vertex_uv,
#     'indices':faces
# }

# import json

# dd = json.dumps(data)
# f = open('xxx.txt','w',encoding='utf-8')
# f.write(dd)
# f.close()


def ma():
    return loadobj_return_vlist_texture(fdir)