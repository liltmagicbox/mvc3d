from math import sqrt, cos,sin,acos

class vec3(list):
    def __init__(self, x,y,z):        
        super().__init__( (x,y,z) )

    def __str__(self):
        return "Vector "+super().__str__()

    def __add__(self,other):
        return [self[0]+other[0], self[1]+other[1] ,self[2]+other[2]]
    def __mul__(self,x):
        return [self[0]*x, self[1]*x ,self[2]*x]


def cross(v1,v2):
    d,e,f = v1
    g,h,i = v2
    x= (e*i-f*h)
    y=-(d*i-f*g)
    z= (d*h-e*g)
    return vec3(x,y,z)

def normalize(v):
    x,y,z = v
    if not x==y==z==0:
        dem = sqrt( x**2+y**2+z**2 )
        return vec3( x/dem, y/dem, z/dem )    
    return vec3(0,0,0)
    

def dot(a,b):
    return a[0]*b[0]+a[1]*b[1]+a[2]*b[2]






def quatel(axis,th):
    axis = normalize(axis)
    x,y,z = axis *sin(th/2)
    w = cos(th/2)
    return x,y,z,w

def mrotel(qx,qy,qz,qw):    
    mat = [
    [1 - 2*qy**2 - 2*qz**2,   2*qx*qy - 2*qz*qw,   2*qx*qz + 2*qy*qw, 0],
    [2*qx*qy + 2*qz*qw,   1 - 2*qx**2 - 2*qz**2,   2*qy*qz - 2*qx*qw, 0],
    [2*qx*qz - 2*qy*qw,   2*qy*qz + 2*qx*qw,   1 - 2*qx**2 - 2*qy**2, 0],
    [0,0,0,1]
    ]
    return mat


def rotmat(axis,th):
    x,y,z,w=quatel(axis,th)
    return mrotel(x,y,z,w)

def modelmat(posx,scale, axis,th):    
    x,y,z,w=quatel(axis,th)
    rot = mrotel(x,y,z,w)
    rot[0][0] = posx
    rot[0][0] *= scale
    rot[1][1] *= scale
    rot[2][2] *= scale
    return rot


def v1v2R(v1,v2):
    v1 = normalize(v1)
    v2 = normalize(v2)
    axis = cross(v1,v2)
    th= dot(v1,v2)
    x,y,z,w = quatel(axis,th)
    R = mrotel(x,y,z,w)
    return R

if __name__ == '__main__':    
    v1=(1,2,3)
    v2=(3,2,5)

    n = normalize(v1)
    c = cross(v1,v2)
    d = dot(v1,v2)
    print(n)
    print(c)
    print(d)
    R = v1v2R(v1,v2)
    print(R)
