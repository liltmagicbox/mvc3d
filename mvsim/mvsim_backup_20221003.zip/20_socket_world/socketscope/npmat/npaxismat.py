import numpy as np
from time import time

def npnorm(v):
    norms = np.linalg.norm(v)
    if not norms == 0:
        return v/norms
    #return np.array( (0,0,0) ).astype('float')
    return np.array( (0.0,0.0,0.0) )

def quataxis(v1,v2):#FULLY OPTIMISED AT NOW..
    front = npnorm(v1)
    facing = npnorm(v2) #we need this for dot->theta.
    
    #c = np.sum(front*facing)
    #c = np.sum(front*facing, axis=1)
    #np.dot(front,facing)

    axis = np.cross( front , facing) #result not unit if th!=90
    axis = npnorm(axis)

    #th = np.arccos( front.dot(facing) )    
    th = np.arccos( np.sum(front*facing, axis=1) ) #this requres both normalized..
    #th.reshape(-1,1)#need same shape, not [1,2,3,].
    #xyzw = np.hstack( (axis,th) ) # err_truth : this acts like: ufunc. wow..    
    return axis,th

def quatel(axis,th):
    axis = npnorm(axis)
    #x,y,z = axis *np.sin(th/2)
    #A = axis * np.sin(th/2).reshape(-1,1) # to broadcast with shapes (2,3) (2,)
    A = axis * np.sin(th/2).reshape(-1,1)
    w = np.cos(th/2)
    return np.column_stack([A,w]) #yeah!!!!!!!


#see np_rowreturn2.py . where it created.
def mrotel(v1):    
    qx,qy,qz,qw = v1[:,0],v1[:,1],v1[:,2],v1[:,3]

    mat = [
    [1 - 2*qy**2 - 2*qz**2,   2*qx*qy - 2*qz*qw,   2*qx*qz + 2*qy*qw, qx*0],
    [2*qx*qy + 2*qz*qw,   1 - 2*qx**2 - 2*qz**2,   2*qy*qz - 2*qx*qw, qx*0],
    [2*qx*qz - 2*qy*qw,   2*qy*qz + 2*qx*qw,   1 - 2*qx**2 - 2*qy**2, qx*0],
    #[qx*0, qx*0, qx*0, 1]#this took 8ms to 9ms!!!
    [qx*0 , qx*0 , qx*0 , np.ones(len(qx)) ]
    ]

    return np.array( mat)
    #return np.array( mat ,'O') # (mat) 20ms, while 'O' 9ms. wow.wow..
    # O O F datatype. since it is complicated.. [][][] deprecated.fine.-not,just..








#-=============not use this..
#np.zeros(len(qx))  same speed for qx*0.
def mrotela(v1):    
    qx,qy,qz,qw = v1[:,0],v1[:,1],v1[:,2],v1[:,3]
    row = [1 - 2*qy**2 - 2*qz**2,   2*qx*qy - 2*qz*qw,   2*qx*qz + 2*qy*qw, np.zeros(len(qx)) ]
    return np.array(row)
def mrotelb(v1):    
    qx,qy,qz,qw = v1[:,0],v1[:,1],v1[:,2],v1[:,3]
    row = [2*qx*qy + 2*qz*qw,   1 - 2*qx**2 - 2*qz**2,   2*qy*qz - 2*qx*qw, np.zeros(len(qx)) ]
    return np.array(row)
def mrotelc(v1):    
    qx,qy,qz,qw = v1[:,0],v1[:,1],v1[:,2],v1[:,3]
    row = [2*qx*qz - 2*qy*qw,   2*qy*qz + 2*qx*qw,   1 - 2*qx**2 - 2*qy**2, np.zeros(len(qx)) ]
    return np.array(row)
def mroteld(v1):    
    qx,qy,qz,qw = v1[:,0],v1[:,1],v1[:,2],v1[:,3]
    #row = [qx*0, qx*0, qx*0, 1]#this calls error. ofcourse. 1 is only 1.
    row = [np.zeros(len(qx)) , np.zeros(len(qx)) , np.zeros(len(qx)) , np.ones(len(qx)) ]
    return np.array(row)




#rotmat 19ms , (scale,trnaslate requires time..) and gpusetup 6ms.   
if __name__=='__main__':
    v1 = np.random.rand(300000).reshape(100000,3)
    v2 = np.random.rand(300000).reshape(100000,3)

    
    #============ 0 , get quaternion. 11ms took.
    t = time()
    axis,th = quataxis(v1,v2)#6ms
    el = quatel(axis,th)#4ms    
    print(time()-t,'qaternion')

    #============1st way. 8ms took. 14ms took.
    t = time()
    q = mrotel(el)#8ms
    print(time()-t)#total 18ms, v1v2->R of 100000s. gpu ready.

    #it's identical for 1st way. ONLY SLOWS. deprecate it!
    #=========== 2nd way. 13-17ms.   NOTE: it also requires GPU setup.
    t = time()
    qa = mrotela(el)
    qb = mrotelb(el)
    qc = mrotelc(el)
    qd = mroteld(el)
    q = np.array([qa,qb,qc,qd]) #we got full float64 3d 4,4,100000 array.
    print(time()-t)#compared 9ms, it took 13-17ms. 2x slower..
    #... 1st also 4x4x100000, why useit then?? yeah. agreed.


    #-=--=-==--==- rotmat phase2, to gpu 4x4 settup. 3ms..?
    t = time()
    A = q[0].T.reshape(1,-1)[0]
    B = q[1].T.reshape(1,-1)[0]
    C = q[2].T.reshape(1,-1)[0]
    D = q[3].T.reshape(1,-1)[0]
    print(time()-t , 'gpusetup') #took 4-8ms,.  fine,fine......so good.. i use it..
    

#=========================== v1v2 to 4x4 not used.
#seems too complex. and it passes quaternion process. so, i bury it. fine.haha.
def vvr(eye,target):
    #up == 0,1,0..maybe?
    newfront = target
    newright = np.cross(newfront, up)
    newup = np.cross(newright,newfront)

    

    

def rotation_matrix_from_vectors(vec1, vec2):
    """ Find the rotation matrix that aligns vec1 to vec2
    :param vec1: A 3d "source" vector
    :param vec2: A 3d "destination" vector
    :return mat: A transform matrix (3x3) which when applied to vec1, aligns it with vec2.
    """
    a, b = (vec1 / np.linalg.norm(vec1)).reshape(3), (vec2 / np.linalg.norm(vec2)).reshape(3)
    v = np.cross(a, b)
    c = np.dot(a, b)
    s = np.linalg.norm(v)
    kmat = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
    rotation_matrix = np.eye(3) + kmat + kmat.dot(kmat) * ((1 - c) / (s ** 2))
    return rotation_matrix
    
v1 = np.random.rand(30).reshape(10,3)
v2 = np.random.rand(30).reshape(10,3)
#vvr(v1, v2)
    
##   
##t = time()
##a=[]
##for i in range(q.shape[-1]):
##    P = q[:,:,i].reshape(1,-1)
##    a.append(P)
##A = np.array(a).reshape(1,-1)[0]
##print(time()-t,'slow way. dont do this')
###if you do this, 100ms happens. too,toobad... i think it will be so.. 



########dont to like this, too, tooo bad!!!!!!!!
##    blen = el.shape[0]
##    blam = np.arange(blen)
##
##    b = blam%4==0
##    b = b[:,np.newaxis]
##    b = np.tile(b, (1,4) )    
##    maska = b
##
##    b = blam%4==1
##    b = b[:,np.newaxis]
##    b = np.tile(b, (1,4) )    
##    maskb = b
##
##    b = blam%4==2
##    b = b[:,np.newaxis]
##    b = np.tile(b, (1,4) )    
##    maskc = b
##
##    b = blam%4==3
##    b = b[:,np.newaxis]
##    b = np.tile(b, (1,4) )    
##    maskd = b
##    
##    ela = el[maska].reshape(-1,4)
##    elb = el[maskb].reshape(-1,4)
##    elc = el[maskc].reshape(-1,4)
##    eld = el[maskd].reshape(-1,4)
##
##    qa = mrotela(ela)
##    qb = mrotelb(elb)
##    qc = mrotelc(elc)
##    qd = mroteld(eld)
########dont to like this, too, tooo bad!!!!!!!!
#---------------------------------------

    

##
##def rotation_matrix_from_vectors(vec1, vec2):
##    """ Find the rotation matrix that aligns vec1 to vec2
##    :param vec1: A 3d "source" vector
##    :param vec2: A 3d "destination" vector
##    :return mat: A transform matrix (3x3) which when applied to vec1, aligns it with vec2.
##    """
##    a, b = (vec1 / np.linalg.norm(vec1)).reshape(3), (vec2 / np.linalg.norm(vec2)).reshape(3)
##    v = np.cross(a, b)
##    c = np.dot(a, b)
##    s = np.linalg.norm(v)
##    kmat = np.array([[0, -v[2], v[1]], [v[2], 0, -v[0]], [-v[1], v[0], 0]])
##    rotation_matrix = np.eye(3) + kmat + kmat.dot(kmat) * ((1 - c) / (s ** 2))
##    return rotation_matrix
##
##    t = time()
##    a=[]
##    #for i in range(q.shape[-1]):
##    for i in range( len(q[0][0]) ):    
##        P = q[:,:,i].reshape(1,-1)
##        a.append(P)
##    A = np.array(a).reshape(1,-1)[0]
##    print(time()-t)#total 18ms, v1v2->R of 100000s. gpu ready.
##    
