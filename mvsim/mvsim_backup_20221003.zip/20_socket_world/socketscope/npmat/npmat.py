import numpy as np
from argsparse import argsparse3
from numpy.linalg import norm

from numpy import radians, sin,cos,tan
from numpy import arccos as acos

class npVector(np.ndarray):
    def __new__(subtype, x,y,z ):
        obj = super().__new__(subtype, shape=(3,), buffer=None, offset=0,
                strides=None, order=None)

        obj[0],obj[1],obj[2] = x,y,z
        obj.x, obj.y, obj.z = x,y,z
        return obj

    def __getattribute__(self,name):
        if name == 'x':
            return self[0]#finally!
            #return self.x max recur..
        elif name == 'y':
            return self[1]
        elif name == 'z':
            return self[2]
        return super().__getattribute__(name)

    def __setattr__(self, name, value):
        if name == 'x':
            self[0] = value
        elif name == 'y':
            self[1] = value
        elif name == 'z':
            self[2] = value
        super().__setattr__(name, value)
        #should it be so??  ..actually both super and self acts like same..
        #else:
            #super().__setattr__(name, value)


def vec3(*args):
    """ in:x, xy, xyz, (xyz) out:xyz
    """
    x,y,z = argsparse3(args)
    return npVector(x,y,z)


from numpy import cross


def normalize(vec):
    """ vec /norm if norm not 0
    """
    norms = norm(vec)
    if not norms == 0:
        return vec/norms
    return vec


def dot(v1,v2):
    return v1.dot(v2)

#----for speed comparison
def quatel(axis,th):
    axis = normalize(axis)
    x,y,z = axis *sin(th/2)
    w = cos(th/2)
    return x,y,z,w
def mrotel(qx,qy,qz,qw):    
    mat = [
    [1 - 2*qy**2 - 2*qz**2,   2*qx*qy - 2*qz*qw,   2*qx*qz + 2*qy*qw, 0],
    [2*qx*qy + 2*qz*qw,   1 - 2*qx**2 - 2*qz**2,   2*qy*qz - 2*qx*qw, 0],
    [2*qx*qz - 2*qy*qw,   2*qy*qz + 2*qx*qw,   1 - 2*qx**2 - 2*qy**2, 0],
    [0,0,0,1]
    ]
    return mat
def rotmat(axis,th):
    x,y,z,w=quatel(axis,th)
    return mrotel(x,y,z,w)
def modelmat(posx,scale, axis,th):    
    x,y,z,w=quatel(axis,th)
    rot = mrotel(x,y,z,w)
    rot[0][0] = posx
    rot[0][0] *= scale
    rot[1][1] *= scale
    rot[2][2] *= scale
    return rot

if __name__ == '__main__':    
    v1=vec3(1,2,3)
    v2=vec3(3,2,5)

    n = normalize(v1)
    c = cross(v1,v2)
    d = dot(v1,v2)
    print(n)
    print(c)
    print(d)
