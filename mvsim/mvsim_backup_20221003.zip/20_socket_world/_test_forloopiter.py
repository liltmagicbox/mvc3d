import timefor

#both 1ms for 100k.
#..means, a logic, can affect 1ms for 100k.

#cost of : access of item / iteration
data = [1,2]

def func():
	a = []
	for i in data:
		if i==1:
			a.append(1)
timefor.run(func)


def func():
	a=[]
	if data[0] ==1:
		a.append(1)
	if data[1] ==1:
		a.append(1)
timefor.run(func)


def func():
	a=[]
	b,c = data
	if b ==1:
		a.append(1)
	if c ==1:
		a.append(1)
timefor.run(func)