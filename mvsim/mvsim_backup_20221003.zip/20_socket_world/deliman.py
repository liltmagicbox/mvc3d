

def get_max_distance(deli):
	idx = len(deli)#123, 2.
	for i in reversed(deli):
		if i!=0:
			return idx
		idx -=1
	return 0

x = get_max_distance([1,0,3,1,2,0,1])

def xfilling(cap, deli):
	print('fill',cap,deli)
	pack = 0
	while len(deli)!=0:
		if pack+deli[-1] <= cap:
			pack+=deli.pop(-1)
		else:
			break
	return pack

def filling(cap, deli):

	print('fill',cap,deli)
	pack = 0
	while len(deli)!=0:
		target = deli.pop(-1)
		if pack+target <= cap:
			pack+=target
		else:
			if pack < cap:
				target -= cap-pack
			if target !=0:
				deli.append(target)
			break
	return pack

def sol(cap,n, deli, pick):
	cost = 0

	#==get distance.
	while len(deli)!=0 or len(pick)!=0:
		distance_deli = get_max_distance(deli)
		distance_pick = get_max_distance(pick)
		distance = max(distance_deli,distance_pick)
		cost+= distance*2

		p1 = filling(cap, deli)
		p2 = filling(cap, pick)
		print(p1,p2, 'cost:',cost)		
	print(deli,pick)
	ans = cost
	return ans


assert 16 == sol( 4,5, [1,0,3,1,2], [0,3,0,4,0] )
assert 30 == sol( 2,7, [1,0,2,0,1,0,2], [0,2,0,1,0,2,0] )
#print()
