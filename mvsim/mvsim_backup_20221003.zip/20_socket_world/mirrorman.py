def get_mindis(x,y, xx,yy):
	return abs(xx-x)+ abs(yy-y)

def ispossible(x,y,r,c,k):
	rem = k - get_mindis(x,y,r,c)
	if rem%2 == 0:
		return True
	return False

#down up left right
#d...l..r..u.

def hangchip(n,m, x,y):
	print(n,m, x,y)
	if x<n:
		x+=1
		return 'd'
	if y>1:
		y-=1
		return 'l'
	if y<m:
		y+=1
		return 'r'
	if x>1:
		x-=1
		return 'u'

def get_closest(n,m,x,y, r,c):
	move = ""	
	while y<c:
		move += 'd'
		y+=1
	while x>r:
		move += 'l'
		x-=1
	while x<r:
		move += 'r'
		x+=1
	while y>c:
		move += 'u'
		y-=1
	return move
	

def hangout(n,m, x,y, N):
	move = ""
	for i in range(N):
		move += hangchip(n,m, x,y)
	return move

def sol(n,m, x,y,r,c, k):
	print(x,y,'to',r,c)
	#===vali
	if not ispossible(x,y,r,c,k):
		return 'impossible'
	#===
	ANS = ""
	print(k,get_mindis(x,y,r,c))
	hanger = k-get_mindis(x,y,r,c)
	hang = hangout(n,m,x,y, hanger)
	clo = get_closest(n,m,x,y,r,c)
	print(hang,clo)	
	return hang+clo

x = sol(3,4, 2,3,3,1, 5)
print(x)

